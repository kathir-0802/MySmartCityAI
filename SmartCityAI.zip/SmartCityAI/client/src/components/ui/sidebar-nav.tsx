import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  LayoutDashboard,
  AlertTriangle,
  Bell,
  LogOut,
  Leaf,
  X,
  HelpCircle,
  Info,
  Zap,
  Bot,
  GamepadIcon,
  SunMoon,
  Share2
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

const items = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    href: "/",
  },
  {
    title: "AI Assistant",
    icon: Bot,
    href: "/ai-assistant",
  },
  {
    title: "BioCharge Stations",
    icon: Zap,
    href: "/biocharge",
  },
  {
    title: "Games & Rewards",
    icon: GamepadIcon,
    href: "/games-rewards",
  },
  {
    title: "Report Issue",
    icon: AlertTriangle,
    href: "/report",
  },
  {
    title: "Notifications",
    icon: Bell,
    href: "/notifications",
  },
  {
    title: "How to Use",
    icon: HelpCircle,
    href: "/how-to-use",
  },
  {
    title: "About Us",
    icon: Info,
    href: "/about",
  },
];

interface SidebarNavProps {
  onClose?: () => void;
}

export function SidebarNav({ onClose }: SidebarNavProps) {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  
  useEffect(() => {
    // Check for system preference on initial load
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
    
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    } else if (prefersDark) {
      setTheme('dark');
      document.documentElement.classList.add('dark');
    }
  }, []);
  
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  return (
    <div className="relative border-r min-h-screen w-[240px] px-3 py-4 flex flex-col bg-background/100 backdrop-blur-lg shadow-lg">
      <div className="flex items-center justify-between px-4 py-2 mb-8">
        <div className="flex items-center">
          <Leaf className="w-6 h-6 text-primary mr-2" />
          <h1 className="text-lg font-semibold">MySmartCity AI</h1>
        </div>
        {onClose && (
          <Button variant="ghost" size="icon" className="md:hidden" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>
      <ScrollArea className="flex-1">
        <div className="space-y-2 py-2">
          {items.map((item) => (
            <Link key={item.href} href={item.href}>
              <Button
                variant={location === item.href ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start",
                  location === item.href &&
                    "bg-primary/10 text-primary hover:bg-primary/20"
                )}
                onClick={onClose}
              >
                <item.icon className="w-4 h-4 mr-2" />
                {item.title}
              </Button>
            </Link>
          ))}
        </div>
      </ScrollArea>
      <div className="mt-auto pt-4 space-y-2">
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={toggleTheme}
        >
          <SunMoon className="w-4 h-4 mr-2" />
          {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
        </Button>
        
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={() => {
            if (navigator.share) {
              navigator.share({
                title: 'MySmartCity AI',
                text: 'Join me on MySmartCity AI to help build a smarter, more sustainable city!',
                url: window.location.origin,
              })
              .catch((error) => console.log('Error sharing', error));
            } else {
              // Fallback for browsers that don't support navigator.share
              window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent('Join me on MySmartCity AI to help build a smarter, more sustainable city! ' + window.location.origin)}`, '_blank');
            }
          }}
        >
          <Share2 className="w-4 h-4 mr-2" />
          Share with Friends
        </Button>
        
        <Button
          variant="ghost"
          className="w-full justify-start hover:bg-destructive/10 hover:text-destructive"
          onClick={() => {
            logoutMutation.mutate();
            onClose?.();
          }}
        >
          <LogOut className="w-4 h-4 mr-2" />
          Logout
        </Button>
      </div>
    </div>
  );
}