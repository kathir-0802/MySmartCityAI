import { useState, useCallback, useEffect } from 'react';
import { GoogleMap, useLoadScript, Marker, InfoWindow } from '@react-google-maps/api';
import { Loader2, MapPin, AlertCircle } from 'lucide-react';
import { Button } from './button';
import { Alert, AlertDescription, AlertTitle } from './alert';

// Center on Malaysia by default (Kuala Lumpur coordinates)
const defaultCenter = { lat: 3.1390, lng: 101.6869 }; // Kuala Lumpur, Malaysia

const mapContainerStyle = {
  width: '100%',
  height: '100%',
  minHeight: '400px',
};

const options = {
  disableDefaultUI: false,
  zoomControl: true,
};

interface MapLocation {
  lat: number;
  lng: number;
  title?: string;
  description?: string;
}

interface GoogleMapComponentProps {
  markers?: MapLocation[];
  onMapClick?: (location: { lat: number; lng: number }) => void;
  center?: { lat: number; lng: number };
  zoom?: number;
}

export function GoogleMapComponent({
  markers = [],
  onMapClick,
  center = defaultCenter,
  zoom = 12,
}: GoogleMapComponentProps) {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "",
  });

  const [selectedMarker, setSelectedMarker] = useState<MapLocation | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>(center);
  const [isCheckingLocation, setIsCheckingLocation] = useState(false);

  // Function to handle location permissions and get user location
  const getUserLocation = useCallback(() => {
    setIsCheckingLocation(true);
    setLocationError(null);

    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser");
      setIsCheckingLocation(false);
      return;
    }

    navigator.permissions.query({ name: 'geolocation' }).then((result) => {
      if (result.state === 'denied') {
        setLocationError("Location permission is denied. Please enable it in your browser settings.");
        setIsCheckingLocation(false);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const newLocation = { lat: latitude, lng: longitude };
          setUserLocation(newLocation);
          setMapCenter(newLocation);
          setIsCheckingLocation(false);
        },
        (error) => {
          switch (error.code) {
            case error.PERMISSION_DENIED:
              setLocationError("Location permission denied. Please enable location services.");
              break;
            case error.POSITION_UNAVAILABLE:
              setLocationError("Location information is unavailable.");
              break;
            case error.TIMEOUT:
              setLocationError("The request to get user location timed out.");
              break;
            default:
              setLocationError("An unknown error occurred while retrieving location.");
              break;
          }
          setIsCheckingLocation(false);
        },
        { timeout: 10000, enableHighAccuracy: true }
      );
    });
  }, []);

  // Try to get user location on component mount
  useEffect(() => {
    getUserLocation();
  }, [getUserLocation]);

  const handleMapClick = useCallback((e: google.maps.MapMouseEvent) => {
    if (onMapClick && e.latLng) {
      onMapClick({
        lat: e.latLng.lat(),
        lng: e.latLng.lng(),
      });
    }
  }, [onMapClick]);

  if (loadError) {
    return <div className="text-red-500">Error loading maps</div>;
  }

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {locationError && (
        <Alert variant="destructive" className="mb-3">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Location Error</AlertTitle>
          <AlertDescription>{locationError}</AlertDescription>
          <Button 
            size="sm" 
            className="mt-2" 
            onClick={getUserLocation}
            disabled={isCheckingLocation}
          >
            {isCheckingLocation ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Checking...
              </>
            ) : (
              <>
                <MapPin className="mr-2 h-4 w-4" />
                Enable Location
              </>
            )}
          </Button>
        </Alert>
      )}
      
      {!locationError && !userLocation && (
        <div className="flex justify-between items-center mb-3 p-2 bg-primary/10 rounded">
          <div className="text-sm">
            {isCheckingLocation ? 'Requesting your location...' : 'Use your current location for better service'}
          </div>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={getUserLocation}
            disabled={isCheckingLocation}
          >
            {isCheckingLocation ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <MapPin className="h-4 w-4" />
            )}
          </Button>
        </div>
      )}
      
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        zoom={zoom}
        center={mapCenter}
        options={options}
        onClick={handleMapClick}
      >
        {markers.map((marker, idx) => (
          <Marker
            key={idx}
            position={{ lat: marker.lat, lng: marker.lng }}
            onClick={() => setSelectedMarker(marker)}
          />
        ))}

        {userLocation && (
          <Marker
            position={userLocation}
            icon={{
              path: google.maps.SymbolPath.CIRCLE,
              scale: 7,
              fillColor: "#4285F4",
              fillOpacity: 1,
              strokeColor: "#FFFFFF",
              strokeWeight: 2,
            }}
          />
        )}

        {selectedMarker && (
          <InfoWindow
            position={{ lat: selectedMarker.lat, lng: selectedMarker.lng }}
            onCloseClick={() => setSelectedMarker(null)}
          >
            <div>
              <h3 className="font-medium">{selectedMarker.title}</h3>
              <p className="text-sm text-gray-600">{selectedMarker.description}</p>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
    </div>
  );
}
