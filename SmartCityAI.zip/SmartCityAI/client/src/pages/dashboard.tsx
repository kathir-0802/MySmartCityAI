import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Award,
  Leaf,
  TrendingUp,
  Car,
  Train,
  Bike,
} from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Welcome back, {user?.username}!</h1>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Eco Points</CardTitle>
            <Award className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{user?.ecoPoints}</div>
            <p className="text-xs text-muted-foreground">
              Points earned from eco-friendly actions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Green Score</CardTitle>
            <Leaf className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{user?.greenScore}%</div>
            <Progress value={user?.greenScore} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">CO₂ Saved</CardTitle>
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24kg</div>
            <p className="text-xs text-muted-foreground">
              This month's carbon savings
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Transport Choices</h2>
        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <Car className="w-8 h-8 mr-4 text-destructive" />
                <div>
                  <h3 className="font-medium">Car Trips</h3>
                  <p className="text-sm text-muted-foreground">3 this week</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <Train className="w-8 h-8 mr-4 text-primary" />
                <div>
                  <h3 className="font-medium">Public Transport</h3>
                  <p className="text-sm text-muted-foreground">12 this week</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <Bike className="w-8 h-8 mr-4 text-primary" />
                <div>
                  <h3 className="font-medium">Bike Rides</h3>
                  <p className="text-sm text-muted-foreground">8 this week</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
