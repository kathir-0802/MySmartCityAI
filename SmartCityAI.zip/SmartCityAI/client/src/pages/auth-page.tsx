import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { InsertUser, LoginData, insertUserSchema, loginSchema, forgotPasswordSchema, resetPasswordSchema } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Leaf, CheckCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AuthPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [resetToken, setResetToken] = useState<string | null>(null);
  
  // Check URL parameters for reset token
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const token = searchParams.get('token');
    if (token) {
      setResetToken(token);
    }
  }, []);

  if (user) {
    setLocation("/");
    return null;
  }

  // If there's a reset token, show the reset password form
  if (resetToken) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <div className="flex items-center space-x-2">
              <Leaf className="w-6 h-6 text-primary" />
              <CardTitle className="text-2xl">Reset Your Password</CardTitle>
            </div>
            <CardDescription>
              Enter your new password below
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResetPasswordForm token={resetToken} />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:grid md:grid-cols-2">
      <div className="flex items-center justify-center p-6 bg-background order-2 md:order-1">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <div className="flex items-center space-x-2">
              <Leaf className="w-6 h-6 text-primary" />
              <CardTitle className="text-2xl">Welcome to MySmartCity AI</CardTitle>
            </div>
            <CardDescription>
              Sign in to access your eco-dashboard and city services
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="space-y-4">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
              <TabsContent value="login">
                <LoginForm />
              </TabsContent>
              <TabsContent value="register">
                <RegisterForm />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      <div className="relative bg-[url('https://images.unsplash.com/photo-1661951933609-8448919fa4ef')] bg-cover bg-center min-h-[200px] md:min-h-screen order-1 md:order-2">
        <div className="absolute inset-0 bg-primary/90 mix-blend-multiply" />
        <div className="absolute inset-0 flex items-center justify-center p-6 md:p-12">
          <div className="max-w-sm text-white">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              Your AI-powered assistant for a smarter, greener city life
            </h2>
            <ul className="space-y-2 md:space-y-4 text-sm md:text-base">
              <li>Track your eco-footprint</li>
              <li>Report city issues instantly</li>
              <li>Earn rewards for sustainable choices</li>
              <li>Get personalized recommendations</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

function LoginForm() {
  const { loginMutation } = useAuth();
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetLinkSent, setResetLinkSent] = useState(false);
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      identifier: "",
      password: "",
    },
  });

  const forgotPasswordForm = useForm({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: "",
    },
  });

  const handleSubmit = (data: LoginData) => {
    loginMutation.mutate(data);
  };

  const handleForgotPassword = async (data: { email: string }) => {
    try {
      const response = await apiRequest("POST", "/api/forgot-password", data);
      const result = await response.json();
      
      // For the demo, if the response includes a resetToken (dev env only), show it to the user
      if (result.resetToken) {
        toast({
          title: "Password Reset Token",
          description: `For demo purposes, your reset token is: ${result.resetToken}`,
        });
      }
      
      setResetLinkSent(true);
      toast({
        title: "Reset link sent",
        description: "If an account exists with this email, you will receive a password reset link",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send reset link. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (showForgotPassword) {
    if (resetLinkSent) {
      return (
        <div className="space-y-4 text-center">
          <div className="inline-flex p-3 rounded-full bg-green-100 text-green-600 mb-2">
            <CheckCircle className="h-8 w-8" />
          </div>
          <h3 className="text-lg font-medium">Check Your Email</h3>
          <p className="text-sm text-muted-foreground">
            We've sent password reset instructions to your email address.
            Please check your inbox.
          </p>
          <div className="pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowForgotPassword(false);
                setResetLinkSent(false);
              }}
              className="w-full"
            >
              Back to Login
            </Button>
          </div>
          <div className="pt-4">
            <p className="text-xs text-muted-foreground">
              Didn't receive an email? Check your spam folder or 
              <Button
                type="button"
                variant="link"
                onClick={() => {
                  setResetLinkSent(false);
                }}
                className="p-0 h-auto text-xs"
              >
                try again
              </Button>
            </p>
          </div>
        </div>
      );
    }
  
    return (
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Reset Your Password</h3>
        <p className="text-sm text-muted-foreground">
          Enter your email address and we'll send you a link to reset your password.
        </p>
        <Form {...forgotPasswordForm}>
          <form
            onSubmit={forgotPasswordForm.handleSubmit(handleForgotPassword)}
            className="space-y-4"
          >
            <FormField
              control={forgotPasswordForm.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input 
                      type="email" 
                      placeholder="Enter your email" 
                      autoComplete="email"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex flex-col space-y-2">
              <Button
                type="submit"
                className="w-full"
                disabled={forgotPasswordForm.formState.isSubmitting}
              >
                Send Reset Link
              </Button>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setShowForgotPassword(false)}
              >
                Back to Login
              </Button>
            </div>
          </form>
        </Form>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(handleSubmit)}
        className="space-y-4"
      >
        <FormField
          control={form.control}
          name="identifier"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Username or Email</FormLabel>
              <FormControl>
                <Input placeholder="Enter your username or email" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Password</FormLabel>
              <FormControl>
                <Input type="password" placeholder="Enter your password" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button
          type="button"
          variant="link"
          className="px-0 font-normal"
          onClick={() => setShowForgotPassword(true)}
        >
          Forgot password?
        </Button>
        <Button
          type="submit"
          className="w-full"
          disabled={loginMutation.isPending}
        >
          Login
        </Button>
      </form>
    </Form>
  );
}

function RegisterForm() {
  const { registerMutation } = useAuth();
  const form = useForm({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
    },
  });

  const handleRegister = (data: InsertUser) => {
    registerMutation.mutate(data);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(handleRegister)}
        className="space-y-4"
      >
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Username</FormLabel>
              <FormControl>
                <Input placeholder="Choose a username" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" placeholder="Enter your email" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Password</FormLabel>
              <FormControl>
                <Input type="password" placeholder="Create a password" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button
          type="submit"
          className="w-full"
          disabled={registerMutation.isPending}
        >
          Register
        </Button>
      </form>
    </Form>
  );
}

function ResetPasswordForm({ token }: { token: string }) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isSuccess, setIsSuccess] = useState(false);
  
  const form = useForm({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      token,
      password: "",
      confirmPassword: "",
    },
  });
  
  const onSubmit = async (data: z.infer<typeof resetPasswordSchema>) => {
    try {
      await apiRequest("POST", "/api/reset-password", {
        token: data.token,
        password: data.password,
      });
      
      setIsSuccess(true);
      toast({
        title: "Password reset successful",
        description: "You can now log in with your new password",
      });
      
      // Redirect to login after 3 seconds
      setTimeout(() => {
        setLocation("/auth");
      }, 3000);
    } catch (error) {
      toast({
        title: "Error resetting password",
        description: error instanceof Error ? error.message : "Please try again or request a new reset link",
        variant: "destructive",
      });
    }
  };
  
  if (isSuccess) {
    return (
      <div className="space-y-4 text-center">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
        <h3 className="text-xl font-medium">Password Reset Successful</h3>
        <p className="text-muted-foreground">
          Your password has been updated. You will be redirected to the login page.
        </p>
      </div>
    );
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>New Password</FormLabel>
              <FormControl>
                <Input 
                  type="password" 
                  placeholder="Enter your new password" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="confirmPassword"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Confirm Password</FormLabel>
              <FormControl>
                <Input 
                  type="password" 
                  placeholder="Confirm your new password" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Button
          type="submit"
          className="w-full"
          disabled={form.formState.isSubmitting}
        >
          Reset Password
        </Button>
      </form>
    </Form>
  );
}