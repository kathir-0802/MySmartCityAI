import { useState, useRef, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  Bot,
  Send,
  Zap,
  Footprints,
  MapPin,
  AlertTriangle,
  ThumbsUp,
  ThumbsDown,
  Share,
  MoreHorizontal,
  Search,
  History,
  ArrowUpRight,
  Info,
  CameraIcon,
  Lightbulb,
  Leaf,
  User,
  Home,
  HelpCircle
} from "lucide-react";

// Message types
type MessageCategory = 'general' | 'biocharge' | 'route' | 'issue' | 'tips' | 'search';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  category?: MessageCategory;
}

// Define suggestion type
type QuickSuggestion = { 
  text: string;
  icon: JSX.Element;
  category: MessageCategory;
};

// Quick suggestion options
const quickSuggestions: QuickSuggestion[] = [
  { text: "Find nearest BioCharge station", icon: <Zap className="h-4 w-4" />, category: 'biocharge' },
  { text: "Report a city issue", icon: <AlertTriangle className="h-4 w-4" />, category: 'issue' },
  { text: "Show my eco-points", icon: <Leaf className="h-4 w-4" />, category: 'general' },
  { text: "Sustainable travel tips", icon: <Footprints className="h-4 w-4" />, category: 'tips' },
  { text: "Get optimal route", icon: <MapPin className="h-4 w-4" />, category: 'route' },
];

// AI Assistant FAQ list for help tab
const faqList = [
  {
    question: "What is BioCharge?",
    answer: "BioCharge is our innovative system that converts kinetic energy from footsteps into electricity, powering public charging stations for devices and e-bikes."
  },
  {
    question: "How do I earn eco-points?",
    answer: "You can earn eco-points by using BioCharge stations, reporting city issues, choosing green transportation options, and completing sustainability challenges."
  },
  {
    question: "How to report an issue?",
    answer: "Go to the 'Report Issue' section, take a photo of the problem, add a description and location, and submit. Our AI will analyze and categorize the issue for quick resolution."
  },
  {
    question: "Can I track my impact on the environment?",
    answer: "Yes! Your personal dashboard shows your Green Score, which tracks your carbon footprint reduction, energy generated, and eco-friendly activities."
  },
  {
    question: "How does the MySmartCity AI assistant help me?",
    answer: "I can help you find nearby BioCharge stations, suggest eco-friendly routes, provide real-time transportation updates, analyze your sustainability habits, and answer questions about city services."
  }
];

// AI response generator function
function generateAIResponse(message: string, category?: MessageCategory): Promise<string> {
  // This simulates an API call to get AI response
  return new Promise((resolve) => {
    setTimeout(() => {
      let response = "";
      const lowerMessage = message.toLowerCase();
      
      // Generate different responses based on query category
      if (category === 'search') {
        response = `🔍 Search results for "${message}"

**Locations Found**
- BioCharge Station near KLCC (0.3 km away)
- Eco-friendly Grocery Store: EarthMart (1.2 km away)
- Electronics Recycling Center (2.5 km away)

**Related Information**
- Recent news about sustainable initiatives in KL
- Upcoming green events in your area
- BioCharge station usage patterns

**Suggested Actions**
- View live BioCharge station status
- Check your eco-point history
- Report a sustainability issue

Which result would you like to explore further?`;
      }
      else if (category === 'biocharge' || lowerMessage.includes('biocharge') || lowerMessage.includes('station')) {
        response = `The closest BioCharge stations to your current location are:
        
1. KLCC BioCharge Station (0.8 km away)
2. Bukit Bintang Walkway BioCharge (1.2 km away)
3. Perdana Botanical Gardens BioCharge (2.5 km away)

KLCC BioCharge Station has generated 245.6 kWh of energy from 18,750 footsteps. Would you like directions to get there?`;
      } 
      else if (category === 'issue' || lowerMessage.includes('report') || lowerMessage.includes('issue')) {
        response = `To report a city issue:

1. Go to the "Report Issue" tab
2. Capture or upload a photo of the problem
3. Add a description and the location
4. Submit your report

Our AI will analyze the image and route your report to the appropriate department. You'll earn 20 eco-points for each verified report!`;
      } 
      else if (category === 'tips' || lowerMessage.includes('tip') || lowerMessage.includes('advice')) {
        response = `Here are some sustainable travel tips for Kuala Lumpur:

• Use the MRT or LRT to reduce your carbon footprint
• Try e-scooters for last-mile connectivity (available at KLCC and KL Sentral)
• Visit BioCharge stations along your route to charge devices with green energy
• Join the weekend car-free morning in Dataran Merdeka area (first Sunday each month)
• Use MySmartCity's route planner to find the most eco-friendly path`;
      }
      else if (category === 'route' || lowerMessage.includes('route') || lowerMessage.includes('direction')) {
        response = `The most eco-friendly route from your location to KLCC:

1. Walk to Masjid Jamek LRT station (350m)
2. Take LRT Kelana Jaya Line to KLCC station (4 stops)
3. Exit via entrance C and use the covered walkway

This route will save approximately 2.4 kg of CO2 compared to using a car or ride-hailing service. You'll also earn 15 eco-points!`;
      }
      else if (lowerMessage.includes('eco-point') || lowerMessage.includes('point')) {
        response = `You currently have 124 eco-points!

Recent activity:
• +50 points from BioCharge station interactions
• +45 points from green commuting choices
• +20 points from reporting a city issue
• +9 points from daily sustainability quiz

You need 26 more points to reach the "Green Guardian" level. Try visiting a BioCharge station or completing a sustainability challenge to earn more!`;
      }
      else if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
        response = `Hello! I'm your MySmartCity AI assistant. I can help you with:

• Finding BioCharge stations
• Planning eco-friendly routes
• Reporting city issues
• Providing sustainability tips
• Tracking your green impact

What would you like to know about today?`;
      }
      else {
        response = `I'll help you with that! As your MySmartCity AI assistant, I can provide information about:

• BioCharge stations around Kuala Lumpur
• Eco-friendly transportation options
• How to earn and use your eco-points
• City sustainability initiatives
• Reporting and tracking urban issues

What specific information would you like to know?`;
      }
      
      resolve(response);
    }, 1000);
  });
}

export default function AIAssistant() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: `Hello ${user?.username}! I'm your MySmartCity AI Assistant. How can I help you today?`,
      sender: 'ai',
      timestamp: new Date(),
      category: 'general'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [searchMode, setSearchMode] = useState(false);
  const [allowCamera, setAllowCamera] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to the most recent message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus input field when component mounts
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // Handle message sending
  const handleSendMessage = async (content: string, category?: MessageCategory) => {
    if (!content.trim()) return;
    
    // Clear input field
    setInputValue('');
    
    // Add user message
    const userMessageId = Date.now().toString();
    const userMessage: Message = {
      id: userMessageId,
      content,
      sender: 'user',
      timestamp: new Date(),
      category
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    // Show AI is typing indicator
    setIsTyping(true);
    
    try {
      // Get AI response
      const aiResponse = await generateAIResponse(content, category);
      
      // Add AI message
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse,
        sender: 'ai',
        timestamp: new Date(),
        category: category || 'general'
      };
      
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get AI response. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsTyping(false);
    }
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      if (searchMode) {
        handleSendMessage(inputValue, 'search');
        setSearchMode(false);
      } else {
        handleSendMessage(inputValue);
      }
    }
  };

  // Activate search mode
  const handleActivateSearch = () => {
    setSearchMode(!searchMode);
    if (!searchMode) {
      toast({
        title: "Search Mode Activated",
        description: "Type your search query for locations, services, or information",
      });
    }
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  // Handle camera permission request
  const handleCameraPermission = () => {
    // In a real implementation, this would request camera permissions
    toast({
      title: "Camera Permission Requested",
      description: "Please allow camera access to take photos for reporting issues",
    });
    
    // Simulate permission being granted
    setTimeout(() => {
      setAllowCamera(true);
      toast({
        title: "Camera Access Granted",
        description: "You can now take photos for evidence when reporting issues",
      });
    }, 1500);
  };

  // Define FAQ type
  type Faq = {
    question: string;
    answer: string;
  };

  // Handle quick suggestion click
  const handleSuggestionClick = (suggestion: QuickSuggestion) => {
    handleSendMessage(suggestion.text, suggestion.category);
  };

  // Handle FAQ click
  const handleFaqClick = (faq: Faq) => {
    // First add the question as a user message
    handleSendMessage(faq.question, 'general');
  };

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Bot className="h-8 w-8 text-primary" />
          MySmartCity AI Assistant
        </h1>
        <p className="text-muted-foreground mt-2">
          Your personal guide to sustainable urban living in Malaysia.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-3">
          <Card className="h-[calc(100vh-12rem)]">
            <CardHeader className="border-b py-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src="/city-assistant.png" />
                    <AvatarFallback className="bg-primary/10">
                      <Bot className="h-6 w-6 text-primary" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-lg">MySmartCity AI</CardTitle>
                    <CardDescription>Malaysia Urban Sustainability Guide</CardDescription>
                  </div>
                </div>
                <div className="flex gap-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" onClick={handleActivateSearch}>
                          <Search className={`h-4 w-4 ${searchMode ? 'text-primary' : ''}`} />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Search for information</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" onClick={handleCameraPermission}>
                          <CameraIcon className={`h-4 w-4 ${allowCamera ? 'text-primary' : ''}`} />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Enable camera for photo evidence</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <History className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Conversation history</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
            </CardHeader>
            
            {/* Quick Help Section above the chat */}
            <div className="border-b">
              <div className="p-4">
                <h3 className="text-sm font-semibold mb-3">Quick Help</h3>
                <div className="flex flex-wrap gap-2">
                  {quickSuggestions.map((suggestion, index) => (
                    <Button 
                      key={index} 
                      variant="outline" 
                      size="sm"
                      className="h-8 text-xs"
                      onClick={() => handleSuggestionClick(suggestion)}
                    >
                      {suggestion.icon}
                      <span className="ml-1">{suggestion.text}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </div>
            
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-28rem)]">
                <div className="flex flex-col p-4 gap-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${
                        message.sender === 'user' ? 'justify-end' : 'justify-start'
                      }`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.sender === 'user'
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted'
                        }`}
                      >
                        {message.category && message.sender === 'ai' && (
                          <Badge variant="outline" className="mb-2">
                            {message.category.charAt(0).toUpperCase() + message.category.slice(1)}
                          </Badge>
                        )}
                        <div className="whitespace-pre-line text-sm">
                          {message.content}
                        </div>
                        <div className="text-xs opacity-70 mt-1 text-right">
                          {message.timestamp.toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </div>
                      </div>
                    </div>
                  ))}
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="max-w-[80%] rounded-lg p-3 bg-muted">
                        <div className="flex items-center gap-1">
                          <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce"></div>
                          <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                          <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
            </CardContent>
            <CardFooter className="border-t p-4">
              <form onSubmit={handleSubmit} className="flex items-center w-full gap-2">
                <div className="relative flex-1">
                  <Input
                    ref={inputRef}
                    type="text"
                    placeholder={searchMode 
                      ? "Search for locations, services, or information..." 
                      : "Ask about BioCharge stations, routes, eco-points..."}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    className={`pr-10 ${searchMode ? 'bg-primary/5' : ''}`}
                  />
                  {searchMode && (
                    <Search className="absolute right-3 top-2.5 h-4 w-4 text-primary" />
                  )}
                </div>
                <Button type="submit" size="icon">
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </CardFooter>
          </Card>
        </div>

        {/* Removed Malaysia AI Resource Hub as requested */}
      </div>
    </div>
  );
}