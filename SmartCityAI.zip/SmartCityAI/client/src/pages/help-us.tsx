import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { HeartHandshake, Mail, Share2, Gift, Coffee, Users } from "lucide-react";

export default function HelpUs() {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <HeartHandshake className="w-6 h-6 text-primary" />
            Help Us Grow
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <section>
            <p className="text-muted-foreground mb-4">
              MySmartCity is on a mission to make our cities smarter, greener, and more sustainable. 
              Your support can help us reach more communities and develop new features that benefit everyone!
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold">Ways You Can Help</h2>
            
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="p-6 border-l-4 border-l-primary">
                <div className="flex items-start gap-4">
                  <Share2 className="w-10 h-10 text-primary p-1.5 bg-primary/10 rounded-lg" />
                  <div>
                    <h3 className="font-medium text-lg mb-2">Spread the Word</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Share MySmartCity with friends, family, and colleagues. The more people using the app, 
                      the greater our collective impact on sustainability!
                    </p>
                    <Button variant="outline" size="sm">
                      Share Now
                    </Button>
                  </div>
                </div>
              </Card>
              
              <Card className="p-6 border-l-4 border-l-primary">
                <div className="flex items-start gap-4">
                  <Gift className="w-10 h-10 text-primary p-1.5 bg-primary/10 rounded-lg" />
                  <div>
                    <h3 className="font-medium text-lg mb-2">Donate</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Your financial support helps us maintain and improve the app, expand our BioCharge network,
                      and develop new sustainability features.
                    </p>
                    <Button variant="outline" size="sm">
                      Support Us
                    </Button>
                  </div>
                </div>
              </Card>
              
              <Card className="p-6 border-l-4 border-l-primary">
                <div className="flex items-start gap-4">
                  <Coffee className="w-10 h-10 text-primary p-1.5 bg-primary/10 rounded-lg" />
                  <div>
                    <h3 className="font-medium text-lg mb-2">Volunteer</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      We're always looking for passionate volunteers to help with community outreach, 
                      events, and local sustainability initiatives.
                    </p>
                    <Button variant="outline" size="sm">
                      Join Our Team
                    </Button>
                  </div>
                </div>
              </Card>
              
              <Card className="p-6 border-l-4 border-l-primary">
                <div className="flex items-start gap-4">
                  <Users className="w-10 h-10 text-primary p-1.5 bg-primary/10 rounded-lg" />
                  <div>
                    <h3 className="font-medium text-lg mb-2">Partner With Us</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Businesses and organizations can partner with us to expand our impact 
                      and create sustainable solutions for communities.
                    </p>
                    <Button variant="outline" size="sm">
                      Become a Partner
                    </Button>
                  </div>
                </div>
              </Card>
            </div>
          </section>

          <section className="mt-12">
            <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
              <Mail className="w-5 h-5 text-primary" />
              Contact Us Directly
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              Have questions or want to discuss ways to contribute? Reach out to our team members!
            </p>
            
            <div className="grid gap-4 md:grid-cols-3">
              <Card className="p-4 border-l-4 border-l-primary">
                <h3 className="font-medium">Kathir</h3>
                <p className="text-sm text-muted-foreground mb-2">Lead Developer</p>
                <a href="mailto:kathir080216@gmail.com" className="text-sm text-primary underline">
                  kathir080216@gmail.com
                </a>
              </Card>
              
              <Card className="p-4 border-l-4 border-l-primary">
                <h3 className="font-medium">Kajan</h3>
                <p className="text-sm text-muted-foreground mb-2">Design & Frontend Developer</p>
                <a href="mailto:kajanmurukan08@gmail.com" className="text-sm text-primary underline">
                  kajanmurukan08@gmail.com
                </a>
              </Card>
              
              <Card className="p-4 border-l-4 border-l-primary">
                <h3 className="font-medium">Vishal</h3>
                <p className="text-sm text-muted-foreground mb-2">AI Integration & Backend Developer</p>
                <a href="mailto:vishal101@gmail.com" className="text-sm text-primary underline">
                  vishal101@gmail.com
                </a>
              </Card>
            </div>
            
            <div className="mt-6 flex justify-center">
              <Button className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Send General Inquiry
              </Button>
            </div>
          </section>
        </CardContent>
      </Card>
    </div>
  );
}