import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf, Globe, Users, Trophy, Zap, Map, PieChart, Trophy as Award } from "lucide-react";

export default function About() {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Leaf className="w-6 h-6 text-primary" />
            About MySmartCity Project
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Globe className="w-5 h-5" />
              Project Vision
            </h2>
            <p className="text-muted-foreground">
              MySmartCity focuses on empowering citizens to track their environmental impact and engage with urban sustainability. Our goal is to make eco-friendly choices more accessible and rewarding for everyone in our community.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              BioCharge Stations
            </h2>
            <p className="text-muted-foreground">
              BioCharge transforms human footstep energy (pressure-based kinetic energy) into public charging stations for small devices like phones and electric bicycles.
            </p>
            <div className="grid gap-6 md:grid-cols-3">
              <Card className="p-4 border-l-4 border-l-green-500">
                <h3 className="font-medium flex items-center gap-2">
                  <Map className="w-4 h-4 text-green-500" />
                  Location Mapping
                </h3>
                <p className="text-sm text-muted-foreground">Maps of energy-generating floor locations throughout the city</p>
              </Card>
              <Card className="p-4 border-l-4 border-l-blue-500">
                <h3 className="font-medium flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-blue-500" />
                  AI Analysis
                </h3>
                <p className="text-sm text-muted-foreground">AI-powered analysis of generated energy & city impact</p>
              </Card>
              <Card className="p-4 border-l-4 border-l-amber-500">
                <h3 className="font-medium flex items-center gap-2">
                  <Award className="w-4 h-4 text-amber-500" />
                  Gamification
                </h3>
                <p className="text-sm text-muted-foreground">Users can collect points & redeem rewards</p>
              </Card>
            </div>
            <div className="mt-4 p-4 bg-primary/5 rounded-lg">
              <h3 className="font-medium mb-2">What Makes BioCharge Unique?</h3>
              <p className="text-sm text-muted-foreground">
                Green energy + interactive experience—users receive direct benefits while contributing to the city's sustainability!
              </p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Users className="w-5 h-5" />
              Key Features
            </h2>
            <div className="grid gap-6 md:grid-cols-3">
              <Card className="p-4">
                <h3 className="font-medium">Eco-Impact Tracking</h3>
                <p className="text-sm text-muted-foreground">Personal dashboard for monitoring environmental contributions</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-medium">City Issue Reporting</h3>
                <p className="text-sm text-muted-foreground">Easy-to-use system for reporting and tracking urban issues</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-medium">Real-time Updates</h3>
                <p className="text-sm text-muted-foreground">Live tracking of eco-points and community impact</p>
              </Card>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Trophy className="w-5 h-5" />
              Project Goals
            </h2>
            <div className="space-y-4">
              <Card className="p-4">
                <h3 className="font-medium">Community Engagement</h3>
                <p className="text-sm text-muted-foreground">Building a platform that encourages active citizen participation</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-medium">Environmental Impact</h3>
                <p className="text-sm text-muted-foreground">Helping citizens make sustainable choices and track their impact</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-medium">Smart City Innovation</h3>
                <p className="text-sm text-muted-foreground">Leveraging technology to create a more sustainable urban environment</p>
              </Card>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-500" />
              Development Team
            </h2>
            <div className="grid gap-6 md:grid-cols-3">
              <Card className="p-4 border-l-4 border-l-indigo-500">
                <h3 className="font-medium">Kathir</h3>
                <p className="text-sm text-muted-foreground">Lead Developer</p>
                <p className="text-sm text-muted-foreground mt-2">kathir080216@gmail.com</p>
              </Card>
              <Card className="p-4 border-l-4 border-l-indigo-500">
                <h3 className="font-medium">Kajan</h3>
                <p className="text-sm text-muted-foreground">Design & Frontend Developer</p>
                <p className="text-sm text-muted-foreground mt-2">kajanmurukan08@gmail.com</p>
              </Card>
              <Card className="p-4 border-l-4 border-l-indigo-500">
                <h3 className="font-medium">Vishal</h3>
                <p className="text-sm text-muted-foreground">AI Integration & Backend Developer</p>
                <p className="text-sm text-muted-foreground mt-2">vishal101@gmail.com</p>
              </Card>
            </div>
          </section>
          
          <section className="mt-4 text-sm text-muted-foreground text-center">
            <p>
              © 2025 MySmartCity Project - All Rights Reserved
            </p>
          </section>
        </CardContent>
      </Card>
    </div>
  );
}