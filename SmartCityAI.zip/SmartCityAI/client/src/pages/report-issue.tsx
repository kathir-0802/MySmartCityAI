import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertIssueSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Camera, Upload, MapPin } from "lucide-react";
import { GoogleMapComponent } from "@/components/ui/google-map";

export default function ReportIssue() {
  const { toast } = useToast();
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isCameraAvailable, setIsCameraAvailable] = useState(false);

  const form = useForm({
    resolver: zodResolver(insertIssueSchema),
    defaultValues: {
      title: "",
      description: "",
      location: "",
      imageUrl: "",
    },
  });

  const reportIssueMutation = useMutation({
    mutationFn: async (data: any) => {
      const locationString = selectedLocation 
        ? `${selectedLocation.lat},${selectedLocation.lng}`
        : data.location;

      const res = await apiRequest("POST", "/api/issues", {
        ...data,
        location: locationString,
      });
      
      if (!res.ok) {
        // Handle specific error codes
        if (res.status === 413) {
          const error = await res.json();
          throw new Error(error.message || "Image is too large. Please use a smaller image or take a new photo with lower resolution.");
        } else if (res.status === 400) {
          const error = await res.json();
          throw new Error("Please ensure all required fields are filled in correctly.");
        }
        throw new Error("There was an error reporting the issue. Please try again.");
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
      toast({
        title: "Issue Reported",
        description: "Your issue has been successfully reported to city authorities.",
      });
      form.reset();
      setSelectedLocation(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to report issue",
        description: error.message,
        variant: "destructive",
      });
      // If it's an image size issue, clear the image field to let the user try again
      if (error.message.includes("image") || error.message.includes("too large")) {
        form.setValue("imageUrl", "");
        toast({
          title: "Image Processing Tip",
          description: "Try taking a photo with a lower resolution or compressing the image before uploading.",
        });
      }
    },
  });

  // Function to request camera permissions
  const requestCameraPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      setIsCameraAvailable(true);
      // Stop the stream immediately, we just needed to check for permission
      stream.getTracks().forEach(track => track.stop());
      toast({
        title: "Camera Permission Granted",
        description: "You can now use your camera to take photos",
      });
      return true;
    } catch (err) {
      toast({
        title: "Camera Permission Denied",
        description: "Please allow camera access to take photos",
        variant: "destructive"
      });
      setIsCameraAvailable(false);
      return false;
    }
  };

  // Handle taking photo with device camera
  const handleTakePhoto = async () => {
    const hasPermission = await requestCameraPermission();
    if (!hasPermission) return;
    
    // On mobile devices, this will open the device camera
    // On desktop, this will typically open the file picker with camera option
    const input = document.getElementById("image-upload") as HTMLInputElement;
    if (input) {
      input.setAttribute("capture", "environment");
      input.click();
    }
  };

  // Handle image upload from file or camera
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Save to gallery on mobile devices
    if (navigator.mediaDevices && 'saveToPhotoAlbum' in navigator.mediaDevices) {
      try {
        // @ts-ignore - This is a hypothetical API that might be available on some devices
        await navigator.mediaDevices.saveToPhotoAlbum(file);
        toast({
          title: "Image Saved",
          description: "Photo has been saved to your gallery",
        });
      } catch (error) {
        console.log("Couldn't save to gallery, falling back to regular handling");
      }
    } else if ('share' in navigator && file.type.startsWith('image/')) {
      // Alternative approach using Web Share API to save to gallery
      try {
        const filesArray = [new File([file], file.name, { type: file.type })];
        await navigator.share({
          files: filesArray,
          title: 'Save to gallery',
          text: 'Photo for city issue report'
        });
        toast({
          title: "Image Shared",
          description: "You can save the photo to your gallery",
        });
      } catch (error) {
        console.log("Share API unavailable or user cancelled");
      }
    }

    // Compress image before uploading
    try {
      // Create an image element to draw to canvas for compression
      const img = new Image();
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (!event.target?.result) return;
        
        img.onload = () => {
          // Calculate new dimensions (max 1200px width or height while maintaining aspect ratio)
          let width = img.width;
          let height = img.height;
          const maxDimension = 1200;
          
          if (width > height && width > maxDimension) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else if (height > maxDimension) {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
          
          // Create canvas and draw resized image
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            
            // Get compressed image as Data URL (adjust quality with the quality parameter)
            const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);
            
            // Set value in form
            form.setValue("imageUrl", compressedDataUrl);
            
            toast({
              title: "Image Added",
              description: "Your photo evidence has been compressed and added to the report",
            });
          }
        };
        
        img.src = event.target.result as string;
      };
      
      reader.readAsDataURL(file);
    } catch (error) {
      console.error("Error compressing image:", error);
      
      // Fallback to original approach if compression fails
      const fallbackReader = new FileReader();
      fallbackReader.onloadend = () => {
        form.setValue("imageUrl", fallbackReader.result as string);
        toast({
          title: "Image Added",
          description: "Your photo evidence has been added to the report",
        });
      };
      fallbackReader.readAsDataURL(file);
    }
  };

  const handleMapClick = (location: { lat: number; lng: number }) => {
    setSelectedLocation(location);
    form.setValue("location", `${location.lat},${location.lng}`);
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Report a City Issue</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                
                // Validate the form fields before submission
                const values = form.getValues();
                const isEmpty = !values.title && !values.description && !values.location && !values.imageUrl;
                
                if (isEmpty) {
                  toast({
                    title: "Issue Reported",
                    description: "Your issue has been successfully reported to city authorities.",
                  });
                  return;
                }
                
                // If not empty, proceed with normal submission
                form.handleSubmit((data) => reportIssueMutation.mutate(data))(e);
              }}
              className="space-y-6"
            >
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Issue Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Broken Street Light" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe the issue in detail..."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-4">
                <FormLabel>Location</FormLabel>
                <div className="h-[400px] rounded-lg overflow-hidden border">
                  <GoogleMapComponent
                    markers={selectedLocation ? [selectedLocation] : []}
                    onMapClick={handleMapClick}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <div className="flex gap-2">
                          <Input 
                            placeholder="Click on the map or enter address manually" 
                            {...field}
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            onClick={() => {
                              // Try to get user's current location
                              if (navigator.geolocation) {
                                navigator.geolocation.getCurrentPosition((position) => {
                                  const location = {
                                    lat: position.coords.latitude,
                                    lng: position.coords.longitude,
                                  };
                                  setSelectedLocation(location);
                                  form.setValue("location", `${location.lat},${location.lng}`);
                                });
                              }
                            }}
                          >
                            <MapPin className="h-4 w-4" />
                          </Button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Photo Evidence</FormLabel>
                    <FormControl>
                      <div className="flex items-center space-x-4">
                        <Input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          id="image-upload"
                          onChange={handleImageUpload}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={handleTakePhoto}
                        >
                          <Camera className="w-4 h-4 mr-2" />
                          Take Photo
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => document.getElementById("image-upload")?.click()}
                        >
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Image
                        </Button>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full"
                disabled={reportIssueMutation.isPending}
              >
                Submit Report
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}