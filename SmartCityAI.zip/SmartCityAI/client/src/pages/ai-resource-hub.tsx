import React from 'react';
import { 
  Bot, 
  HelpCircle, 
  Book, 
  FileText, 
  Leaf, 
  MapPin, 
  Zap, 
  AlertTriangle,
  LayoutDashboard,
  ArrowRight,
  ExternalLink,
  Info
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/use-auth';
import { Link } from 'wouter';

export default function AIResourceHub() {
  const { user } = useAuth();

  // Resource categories
  const resourceCategories = [
    {
      id: 'guides',
      title: 'User Guides',
      description: 'Learn how to use the MySmartCity AI features',
      icon: <Book className="h-5 w-5 text-primary" />,
    },
    {
      id: 'malaysiaInfo',
      title: 'Malaysia Info',
      description: 'Resources about sustainable initiatives in Malaysia',
      icon: <FileText className="h-5 w-5 text-primary" />,
    },
    {
      id: 'aiFeatures',
      title: 'AI Features',
      description: 'Explore all AI capabilities',
      icon: <Bot className="h-5 w-5 text-primary" />,
    }
  ];

  // Resource items for each category
  const resources = {
    guides: [
      {
        title: 'Getting Started with MySmartCity AI',
        description: 'Learn the basics of navigating and using the AI assistant',
        link: '/how-to-use',
        internal: true,
      },
      {
        title: 'BioCharge Station Locator Guide',
        description: 'How to find and use BioCharge stations around Malaysia',
        link: '/biocharge',
        internal: true,
      },
      {
        title: 'Reporting City Issues Guide',
        description: 'Step-by-step instructions for reporting urban issues',
        link: '/report',
        internal: true,
      },
      {
        title: 'Understanding Your Eco Score',
        description: 'Learn how your actions contribute to your sustainability metrics',
        link: '/dashboard',
        internal: true,
      },
    ],
    malaysiaInfo: [
      {
        title: 'Malaysia Green Technology Corporation',
        description: 'Official resources for green tech initiatives in Malaysia',
        link: 'https://www.mgtc.gov.my/',
        internal: false,
      },
      {
        title: 'Malaysia Sustainable Development Goals',
        description: 'National progress on UN Sustainable Development Goals',
        link: 'https://www.malaysia.gov.my/portal/content/30901',
        internal: false,
      },
      {
        title: 'KL Smart City Initiatives',
        description: 'Kuala Lumpur\'s ongoing smart city projects and plans',
        link: 'https://www.dbkl.gov.my/',
        internal: false,
      },
      {
        title: 'Malaysia Energy Commission',
        description: 'Resources on energy efficiency and renewable initiatives',
        link: 'https://www.st.gov.my/',
        internal: false,
      },
    ],
    aiFeatures: [
      {
        title: 'AI Assistant Chat',
        description: 'Ask questions and get personalized sustainability guidance',
        link: '/ai-assistant',
        internal: true,
      },
      {
        title: 'Route Optimization',
        description: 'AI-powered eco-friendly route suggestions',
        link: '/ai-assistant?query=route',
        internal: true,
      },
      {
        title: 'Sustainability Tips',
        description: 'Daily AI-generated eco tips specific to Malaysia',
        link: '/ai-assistant?query=tips',
        internal: true,
      },
      {
        title: 'Issue Detection',
        description: 'AI-assisted city issue identification from images',
        link: '/report',
        internal: true,
      },
    ],
  };

  // Quick stats data
  const quickStats = [
    {
      label: 'BioCharge Stations',
      value: '26',
      icon: <Zap className="h-5 w-5 text-primary" />,
    },
    {
      label: 'Cities Covered',
      value: '8',
      icon: <MapPin className="h-5 w-5 text-primary" />,
    },
    {
      label: 'Issues Solved',
      value: '1,248',
      icon: <AlertTriangle className="h-5 w-5 text-primary" />,
    },
    {
      label: 'CO₂ Saved (tons)',
      value: '786',
      icon: <Leaf className="h-5 w-5 text-primary" />,
    },
  ];

  return (
    <div className="container py-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Bot className="h-8 w-8 text-primary" />
          Malaysia AI Resource Hub
        </h1>
        <p className="text-muted-foreground mt-2">
          Your central resource for smart city AI tools and Malaysian sustainability information
        </p>
      </div>

      {/* Quick Stats Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {quickStats.map((stat, index) => (
          <Card key={index} className="bg-muted/50">
            <CardContent className="p-4 flex flex-col items-center justify-center text-center">
              <div className="bg-primary/10 p-3 rounded-full mb-3">
                {stat.icon}
              </div>
              <h3 className="text-2xl font-bold">{stat.value}</h3>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* About Section */}
      <Card className="mb-8">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" />
            <CardTitle>About This Project</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            The MySmartCity AI application was developed by Kathir, Kajan, and Vishal
            to enhance urban sustainability across Malaysia. 
          </p>
          <p className="mb-4">
            Our mission is to enable citizens to track environmental impact, report city issues,
            and engage with urban sustainability efforts through cutting-edge AI technology.
          </p>
          <div className="flex flex-wrap gap-2 mt-4">
            <Badge variant="outline" className="bg-primary/10">AI-powered</Badge>
            <Badge variant="outline" className="bg-primary/10">Sustainable Cities</Badge>
            <Badge variant="outline" className="bg-primary/10">Malaysian Innovation</Badge>
            <Badge variant="outline" className="bg-primary/10">Green Technology</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Resources Tabs */}
      <Card>
        <CardHeader>
          <CardTitle>Resources & Guides</CardTitle>
          <CardDescription>
            Explore guides, Malaysian sustainability resources, and AI feature documentation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="guides">
            <TabsList className="grid grid-cols-3 mb-4">
              {resourceCategories.map((category) => (
                <TabsTrigger key={category.id} value={category.id} className="flex gap-2 items-center">
                  {category.icon}
                  <span className="hidden sm:inline">{category.title}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {Object.keys(resources).map((categoryKey) => (
              <TabsContent key={categoryKey} value={categoryKey} className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {resources[categoryKey as keyof typeof resources].map((resource, index) => (
                    <Card key={index} className="overflow-hidden">
                      <CardContent className="p-0">
                        <div className="p-4">
                          <h3 className="font-semibold flex items-center gap-1">
                            {resource.title}
                            {!resource.internal && <ExternalLink className="h-3 w-3 text-muted-foreground" />}
                          </h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {resource.description}
                          </p>
                        </div>
                        <Separator />
                        <div className="p-3 flex justify-end bg-muted/30">
                          {resource.internal ? (
                            <Link href={resource.link}>
                              <Button variant="ghost" size="sm" className="gap-1">
                                View <ArrowRight className="h-3 w-3" />
                              </Button>
                            </Link>
                          ) : (
                            <a href={resource.link} target="_blank" rel="noopener noreferrer">
                              <Button variant="ghost" size="sm" className="gap-1">
                                Visit <ExternalLink className="h-3 w-3" />
                              </Button>
                            </a>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-muted/30">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarFallback className="bg-primary text-primary-foreground">
                <Bot className="h-5 w-5" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium">Need personalized help?</h3>
              <p className="text-sm text-muted-foreground">
                Our AI assistant can provide customized guidance
              </p>
            </div>
          </div>
          <Link href="/ai-assistant">
            <Button>
              <Bot className="mr-2 h-4 w-4" /> 
              Chat with AI Assistant
            </Button>
          </Link>
        </CardFooter>
      </Card>

      {/* User Stats */}
      {user && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <LayoutDashboard className="h-5 w-5 text-primary" />
              Your Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <h3 className="text-sm font-medium mb-2">Eco Score</h3>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl font-bold">{user.greenScore || 0}</span>
                  <Badge variant="outline" className="bg-primary/10">
                    {user.greenScore > 100 ? 'Eco Champion' : 
                     user.greenScore > 50 ? 'Eco Supporter' : 'Getting Started'}
                  </Badge>
                </div>
                <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-green-400 to-green-600 h-full"
                    style={{ width: `${Math.min((user.greenScore || 0) / 2, 100)}%` }}
                  />
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium mb-2">Eco Points</h3>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl font-bold">{user.ecoPoints || 0}</span>
                  <Badge>Redeemable</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  You can redeem these points for discounts on public transportation and eco-friendly products.
                </p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t">
            <Link href="/">
              <Button variant="outline" className="w-full sm:w-auto">
                View Full Dashboard
              </Button>
            </Link>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}