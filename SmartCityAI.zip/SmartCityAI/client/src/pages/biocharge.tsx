import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GoogleMapComponent } from "@/components/ui/google-map";
import { Button } from "@/components/ui/button";
import { 
  Zap, 
  Footprints, 
  Battery, 
  Leaf, 
  LineChart, 
  ZapOff,
  Loader2
} from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

type BioChargeStation = {
  id: number;
  name: string;
  location: { lat: number; lng: number };
  status: string;
  energyGenerated: number;
  footstepsCount: number;
  lastUpdated: string;
};

type BioChargeStats = {
  totalEnergyGenerated: number;
  totalFootsteps: number;
  co2Saved: number;
  deviceCharged: number;
  bikeCharged: number;
  topStation: {
    id: number;
    name: string;
    energyGenerated: number;
  };
  userContribution: {
    footsteps: number;
    energyGenerated: number;
    pointsEarned: number;
  };
};

export default function BioCharge() {
  const { user } = useAuth();
  const { isConnected, sendFootstepData, requestStationStatus, refreshBioChargeStats, lastFootstepData } = useWebSocket();
  const { toast } = useToast();
  const [selectedStation, setSelectedStation] = useState<BioChargeStation | null>(null);
  const [footstepCount, setFootstepCount] = useState(100); // Default 100 steps
  const [generating, setGenerating] = useState(false);

  // Fetch BioCharge stations
  const { data: stations, isLoading: isLoadingStations } = useQuery<BioChargeStation[]>({
    queryKey: ['/api/biocharge/stations'],
    refetchInterval: 60000, // Refresh every minute
  });

  // Fetch BioCharge statistics
  const { data: stats, isLoading: isLoadingStats } = useQuery<BioChargeStats>({
    queryKey: ['/api/biocharge/stats'],
    refetchInterval: 60000, // Refresh every minute
  });

  const handleStationSelect = (station: BioChargeStation) => {
    setSelectedStation(station);
    toast({
      title: station.name,
      description: `Status: ${station.status} - Energy Generated: ${station.energyGenerated.toFixed(1)} kWh`,
    });
  };

  const handleGenerateEnergy = () => {
    if (!selectedStation) {
      toast({
        title: "No Station Selected",
        description: "Please select a BioCharge station first",
        variant: "destructive"
      });
      return;
    }

    if (selectedStation.status !== "active") {
      toast({
        title: "Station Unavailable",
        description: "This station is currently not operational. Please try another one.",
        variant: "destructive"
      });
      return;
    }

    if (!isConnected) {
      toast({
        title: "Connection Error",
        description: "Not connected to server. Please refresh and try again.",
        variant: "destructive"
      });
      return;
    }

    // Start the generation animation
    setGenerating(true);
    
    // Send the footstep data to the server via WebSocket
    sendFootstepData(selectedStation.id, footstepCount);
    
    // Simulate the generation process with a timeout
    setTimeout(() => {
      setGenerating(false);
      refreshBioChargeStats();
      
      // Request real-time station status update
      requestStationStatus(selectedStation.id);
    }, 1500);
  };
  
  // Store recent energy generation activities
  const [recentActivities, setRecentActivities] = useState<Array<{
    timestamp: Date;
    stationId: number;
    stationName?: string;
    footsteps: number;
    energy: number;
    pointsEarned: number;
  }>>([]);
  
  // Effect to reset generating state when footstep data is received
  // and add new activity to the list
  useEffect(() => {
    if (lastFootstepData) {
      setGenerating(false);
      
      // Find station name if available
      const stationName = stations?.find(s => s.id === lastFootstepData.stationId)?.name;
      
      // Add new activity to the list
      setRecentActivities(prev => [
        {
          timestamp: new Date(),
          stationId: lastFootstepData.stationId,
          stationName,
          footsteps: lastFootstepData.footsteps,
          energy: lastFootstepData.energyGenerated,
          pointsEarned: lastFootstepData.pointsEarned
        },
        ...prev.slice(0, 4) // Keep only the most recent 5 activities
      ]);
    }
  }, [lastFootstepData, stations]);

  // Map the stations to markers for the GoogleMapComponent
  const markers = stations?.map(station => ({
    lat: station.location.lat,
    lng: station.location.lng,
    title: station.name,
    description: `Status: ${station.status} - Energy: ${station.energyGenerated.toFixed(1)} kWh`
  })) || [];

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Zap className="h-8 w-8 text-yellow-500" />
          BioCharge
        </h1>
        <p className="text-muted-foreground mt-2">
          Convert your footsteps into electricity! Locate BioCharge stations, generate power, and earn rewards.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Footprints className="h-5 w-5" />
                BioCharge Stations Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[500px] rounded-lg overflow-hidden border">
                {isLoadingStations ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <GoogleMapComponent 
                    markers={markers}
                    onMapClick={(location) => {
                      const closestStation = stations?.reduce((closest, station) => {
                        const distance = Math.sqrt(
                          Math.pow(station.location.lat - location.lat, 2) + 
                          Math.pow(station.location.lng - location.lng, 2)
                        );
                        
                        if (!closest || distance < closest.distance) {
                          return { station, distance };
                        }
                        return closest;
                      }, null as { station: BioChargeStation, distance: number } | null);
                      
                      if (closestStation && closestStation.distance < 0.01) {
                        setSelectedStation(closestStation.station);
                      }
                    }}
                  />
                )}
              </div>

              <div className="mt-4">
                <h3 className="font-semibold mb-2">Selected Station</h3>
                {selectedStation ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className="p-4 border-l-4 border-l-primary">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">{selectedStation.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            Last updated: {new Date(selectedStation.lastUpdated).toLocaleString()}
                          </p>
                        </div>
                        {selectedStation.status === "active" ? (
                          <Zap className="h-5 w-5 text-green-500" />
                        ) : (
                          <ZapOff className="h-5 w-5 text-red-500" />
                        )}
                      </div>
                    </Card>
                    <Card className="p-4">
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Status:</span>
                          <span className={`text-sm font-medium ${selectedStation.status === "active" ? "text-green-500" : "text-red-500"}`}>
                            {selectedStation.status.toUpperCase()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Energy Generated:</span>
                          <span className="text-sm font-medium">{selectedStation.energyGenerated.toFixed(1)} kWh</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Footsteps Count:</span>
                          <span className="text-sm font-medium">{selectedStation.footstepsCount.toLocaleString()}</span>
                        </div>
                      </div>
                    </Card>
                  </div>
                ) : (
                  <p className="text-muted-foreground">Click on a station marker on the map to select it.</p>
                )}
              </div>

              <div className="mt-6">
                <h3 className="font-semibold mb-2">Generate Energy Now</h3>
                {generating && (
                  <div className="relative mb-4 overflow-hidden rounded-lg border p-4 bg-primary/5">
                    <div className="flex items-center gap-3">
                      <div className="flex-shrink-0">
                        <div className="relative">
                          <Footprints className="h-8 w-8 text-primary animate-bounce" />
                          <span className="absolute -bottom-1 -right-1 h-3 w-3 rounded-full bg-green-500 animate-ping" />
                        </div>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-medium mb-1">Generating Energy...</h4>
                        <div className="h-2 w-full bg-secondary overflow-hidden rounded-full">
                          <div className="h-full bg-primary animate-pulse" style={{ width: '100%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
                  <div className="flex-1">
                    <label className="block text-sm text-muted-foreground mb-1">Number of Footsteps:</label>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        onClick={() => setFootstepCount(Math.max(50, footstepCount - 50))}
                      >
                        -50
                      </Button>
                      <div className="flex-1 h-10 px-3 py-2 border rounded-md flex items-center justify-center">
                        {footstepCount} steps
                      </div>
                      <Button 
                        variant="outline" 
                        onClick={() => setFootstepCount(footstepCount + 50)}
                      >
                        +50
                      </Button>
                    </div>
                  </div>
                  <Button
                    className="w-full md:w-auto"
                    disabled={!selectedStation || selectedStation.status !== "active" || !isConnected || generating}
                    onClick={handleGenerateEnergy}
                  >
                    {generating ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Generating Energy...
                      </>
                    ) : (
                      <>
                        <Zap className="mr-2 h-4 w-4" />
                        Start Generating
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LineChart className="h-5 w-5" />
                Energy Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingStats ? (
                <div className="flex items-center justify-center h-32">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : stats ? (
                <Tabs defaultValue="overall">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="overall">Overall</TabsTrigger>
                    <TabsTrigger value="personal">Your Impact</TabsTrigger>
                  </TabsList>
                  <TabsContent value="overall" className="space-y-4 mt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Card className="p-4">
                        <div className="flex flex-col items-center">
                          <Battery className="h-8 w-8 text-green-500 mb-2" />
                          <span className="text-xl font-bold">{stats.totalEnergyGenerated.toFixed(1)}</span>
                          <span className="text-xs text-muted-foreground">kWh Generated</span>
                        </div>
                      </Card>
                      <Card className="p-4">
                        <div className="flex flex-col items-center">
                          <Footprints className="h-8 w-8 text-amber-500 mb-2" />
                          <span className="text-xl font-bold">{stats.totalFootsteps.toLocaleString()}</span>
                          <span className="text-xs text-muted-foreground">Footsteps</span>
                        </div>
                      </Card>
                    </div>
                    <Card className="p-4">
                      <h3 className="font-medium mb-2">Top Performing Station</h3>
                      <p className="text-sm font-semibold">{stats.topStation.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {stats.topStation.energyGenerated.toFixed(1)} kWh Generated
                      </p>
                    </Card>
                    <Card className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-sm">CO₂ Saved</span>
                        <span className="text-sm font-medium">{stats.co2Saved.toFixed(1)} kg</span>
                      </div>
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-sm">Devices Charged</span>
                        <span className="text-sm font-medium">{stats.deviceCharged.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">E-Bikes Charged</span>
                        <span className="text-sm font-medium">{stats.bikeCharged.toLocaleString()}</span>
                      </div>
                    </Card>
                  </TabsContent>
                  <TabsContent value="personal" className="space-y-4 mt-4">
                    <Card className="p-4 border-l-4 border-l-green-500">
                      <div className="flex items-center gap-3">
                        <Leaf className="h-8 w-8 text-green-500" />
                        <div>
                          <h3 className="font-medium">Your Green Impact</h3>
                          <p className="text-xs text-muted-foreground">Based on your BioCharge activity</p>
                        </div>
                      </div>
                    </Card>
                    <div className="grid grid-cols-2 gap-4">
                      <Card className="p-4">
                        <div className="flex flex-col items-center">
                          <Footprints className="h-6 w-6 text-primary mb-2" />
                          <span className="text-xl font-bold">{stats.userContribution.footsteps}</span>
                          <span className="text-xs text-muted-foreground">Your Footsteps</span>
                        </div>
                      </Card>
                      <Card className="p-4">
                        <div className="flex flex-col items-center">
                          <Zap className="h-6 w-6 text-yellow-500 mb-2" />
                          <span className="text-xl font-bold">{stats.userContribution.energyGenerated.toFixed(1)}</span>
                          <span className="text-xs text-muted-foreground">kWh Generated</span>
                        </div>
                      </Card>
                    </div>
                    <Card className="p-4 bg-primary/5">
                      <h3 className="font-medium mb-1">Eco-Points Earned</h3>
                      <div className="flex items-end gap-1">
                        <span className="text-2xl font-bold text-primary">{stats.userContribution.pointsEarned}</span>
                        <span className="text-xs text-muted-foreground mb-1">points</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        Keep stepping to earn more points and unlock rewards!
                      </p>
                    </Card>
                  </TabsContent>
                </Tabs>
              ) : (
                <p className="text-muted-foreground">No statistics available.</p>
              )}
            </CardContent>
          </Card>

          {recentActivities.length > 0 && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-blue-500" />
                  Recent Activities
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {recentActivities.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3 border-b pb-3 last:border-0 last:pb-0">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                      <Footprints className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">
                        {activity.footsteps} steps at {activity.stationName || `Station ${activity.stationId}`}
                      </p>
                      <div className="mt-1 flex justify-between text-xs text-muted-foreground">
                        <span>{activity.energy.toFixed(2)} kWh</span>
                        <span>+{activity.pointsEarned} points</span>
                        <span>{activity.timestamp.toLocaleTimeString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-yellow-500" />
                How It Works
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-3 items-start">
                <div className="bg-primary/10 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                  <span className="font-bold">1</span>
                </div>
                <div>
                  <h3 className="font-medium">Find a BioCharge Station</h3>
                  <p className="text-sm text-muted-foreground">Locate an active station on the map</p>
                </div>
              </div>
              <div className="flex gap-3 items-start">
                <div className="bg-primary/10 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                  <span className="font-bold">2</span>
                </div>
                <div>
                  <h3 className="font-medium">Walk on Energy Tiles</h3>
                  <p className="text-sm text-muted-foreground">Your footsteps generate kinetic energy</p>
                </div>
              </div>
              <div className="flex gap-3 items-start">
                <div className="bg-primary/10 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                  <span className="font-bold">3</span>
                </div>
                <div>
                  <h3 className="font-medium">Earn Eco-Points</h3>
                  <p className="text-sm text-muted-foreground">Track your impact and collect rewards</p>
                </div>
              </div>
              <div className="flex gap-3 items-start">
                <div className="bg-primary/10 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                  <span className="font-bold">4</span>
                </div>
                <div>
                  <h3 className="font-medium">Charge Devices</h3>
                  <p className="text-sm text-muted-foreground">Use the stations to charge your phone or e-bike</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}