import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  MapPin, 
  Bell, 
  Star, 
  Leaf, 
  Bus, 
  Bike, 
  Car, 
  LineChart,
  Zap,
  Footprints,
  Phone,
  Map
} from "lucide-react";

export default function HowToUse() {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Leaf className="w-6 h-6 text-primary" />
            How to Use MySmartCity AI
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              BioCharge System
            </h2>
            <div className="bg-primary/5 p-4 rounded-lg mb-4">
              <p className="text-muted-foreground">
                BioCharge converts the kinetic energy from your footsteps into electricity to power public charging stations for phones and electric bicycles!
              </p>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              <Card className="p-4 border-l-4 border-l-amber-500">
                <div className="flex items-center gap-2 mb-2">
                  <Footprints className="w-5 h-5 text-amber-500" />
                  <h3 className="font-medium">Step & Generate</h3>
                </div>
                <p className="text-sm text-muted-foreground">Visit any BioCharge location on the map and simply walk on the energy-generating floors.</p>
              </Card>
              <Card className="p-4 border-l-4 border-l-green-500">
                <div className="flex items-center gap-2 mb-2">
                  <Phone className="w-5 h-5 text-green-500" />
                  <h3 className="font-medium">Charge Devices</h3>
                </div>
                <p className="text-sm text-muted-foreground">Plug in your phone or e-bike to use the clean energy you've just generated!</p>
              </Card>
              <Card className="p-4 border-l-4 border-l-blue-500">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-blue-500" />
                  <h3 className="font-medium">Earn Rewards</h3>
                </div>
                <p className="text-sm text-muted-foreground">Each step earns eco-points you can exchange for rewards and discounts around the city.</p>
              </Card>
            </div>
            <div className="mt-4 space-y-2">
              <h3 className="font-medium flex items-center gap-2">
                <Map className="w-4 h-4" />
                Finding BioCharge Stations
              </h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Open the dashboard and check the BioCharge map</li>
                <li>Look for energy tiles marked in high-traffic areas like transit centers and parks</li>
                <li>Visit these locations and start generating energy with your footsteps</li>
              </ul>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Reporting City Issues
            </h2>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Click on "Report Issue" in the sidebar</li>
              <li>Fill in the issue details and location</li>
              <li>Use the map to pinpoint the exact location</li>
              <li>Add a photo for better identification</li>
              <li>Submit your report</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <LineChart className="w-5 h-5" />
              Tracking Your Impact
            </h2>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>View your eco-points on the dashboard</li>
              <li>Check your green score progress</li>
              <li>Monitor your carbon savings</li>
              <li>Track the energy you've generated through the BioCharge system</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Star className="w-5 h-5" />
              Earning Eco-Points
            </h2>
            <div className="grid gap-4 md:grid-cols-3">
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Bus className="w-5 h-5 text-primary" />
                  <h3 className="font-medium">Public Transport</h3>
                </div>
                <p className="text-sm text-muted-foreground">Use public transport to earn points</p>
              </Card>
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Bike className="w-5 h-5 text-primary" />
                  <h3 className="font-medium">Cycling</h3>
                </div>
                <p className="text-sm text-muted-foreground">Choose bikes for short trips</p>
              </Card>
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Footprints className="w-5 h-5 text-primary" />
                  <h3 className="font-medium">BioCharge Steps</h3>
                </div>
                <p className="text-sm text-muted-foreground">Walk on energy-generating floors to earn bonus points</p>
              </Card>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Staying Updated
            </h2>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Enable notifications to receive updates</li>
              <li>Check the notifications tab for status changes</li>
              <li>Get real-time updates on your reports</li>
              <li>Receive eco-tips and achievements</li>
              <li>Get alerts about new BioCharge stations in your area</li>
            </ul>
          </section>
        </CardContent>
      </Card>
    </div>
  );
}
