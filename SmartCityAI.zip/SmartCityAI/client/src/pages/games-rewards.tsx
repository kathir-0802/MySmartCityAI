import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GamepadIcon, Gift, Award, Zap, Leaf, Trophy, ArrowRight, CheckCircle, Star } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/use-websocket";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

// Types for challenges and rewards
type Challenge = {
  id: number;
  title: string;
  description: string;
  reward: number;
  progress: number;
  type: 'footsteps' | 'reports' | 'invites' | 'commutes';
  goal: number;
  current: number;
  completedDate?: string;
  imageIcon: React.ReactNode;
};

type Reward = {
  id: number;
  title: string;
  description: string;
  points: number;
  image: string;
  category: 'transport' | 'energy' | 'environment' | 'education';
};

export default function GamesRewards() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { isConnected, lastFootstepData } = useWebSocket();
  const queryClient = useQueryClient();
  const [currentTab, setCurrentTab] = useState("rewards");
  const userPoints = user?.ecoPoints || 0;
  
  // Demo rewards data - in a real app this would come from the server
  const rewards: Reward[] = [
    {
      id: 1,
      title: "Free Bus Pass",
      description: "Get a free 1-day bus pass for your city commutes",
      points: 500,
      image: "/bus-pass.svg",
      category: 'transport'
    },
    {
      id: 2,
      title: "Electric Scooter Rental",
      description: "30-minute free e-scooter rental in participating locations",
      points: 750,
      image: "/scooter.svg",
      category: 'transport'
    },
    {
      id: 3,
      title: "Tree Planting",
      description: "We'll plant a tree in your name in the city's green areas",
      points: 1000,
      image: "/tree.svg",
      category: 'environment'
    },
    {
      id: 4,
      title: "Power Bank Charging",
      description: "Free charging for your power bank at any BioCharge station",
      points: 250,
      image: "/power-bank.svg",
      category: 'energy'
    },
    {
      id: 5,
      title: "Eco-Store Discount",
      description: "15% discount at participating eco-friendly stores",
      points: 800,
      image: "/store.svg",
      category: 'environment'
    },
    {
      id: 6,
      title: "Sustainability Workshop",
      description: "Free entry to the next city sustainability workshop",
      points: 600,
      image: "/workshop.svg",
      category: 'education'
    }
  ];
  
  // State for challenges - we'll create a state-based tracking system since we don't have a dedicated API endpoint
  const [challenges, setChallenges] = useState<Challenge[]>([
    {
      id: 1,
      title: "Footstep Champion",
      description: "Generate 1000 footsteps at BioCharge stations this week",
      reward: 200,
      type: 'footsteps',
      goal: 1000,
      current: 350,
      progress: 35,
      imageIcon: <Footprints className="w-5 h-5 text-primary" />
    },
    {
      id: 2,
      title: "Recycling Hero",
      description: "Report 5 recycling locations in your neighborhood",
      reward: 150,
      type: 'reports',
      goal: 5,
      current: 3,
      progress: 60,
      imageIcon: <Recycle className="w-5 h-5 text-green-500" />
    },
    {
      id: 3,
      title: "Clean Energy Advocate",
      description: "Spread the word by inviting 3 friends to the app",
      reward: 100,
      type: 'invites',
      goal: 3,
      current: 0,
      progress: 0,
      imageIcon: <Users className="w-5 h-5 text-blue-500" />
    },
    {
      id: 4,
      title: "Green Transport Warrior",
      description: "Log 10 eco-friendly commutes this month",
      reward: 250,
      type: 'commutes',
      goal: 10,
      current: 7,
      progress: 70,
      imageIcon: <Bike className="w-5 h-5 text-primary" />
    }
  ]);
  
  // Handle redemption of rewards
  const redeemRewardMutation = useMutation({
    mutationFn: async (rewardId: number) => {
      // In a real app, this would call an API endpoint
      const reward = rewards.find(r => r.id === rewardId);
      if (!reward) throw new Error("Reward not found");
      
      // Here we're just simulating the API call
      return { success: true, reward };
    },
    onSuccess: (data) => {
      // Reduce the user's points
      if (user) {
        queryClient.setQueryData(['/api/user'], (oldData: any) => ({
          ...oldData,
          ecoPoints: oldData.ecoPoints - data.reward.points,
        }));
      }
      
      // Show success message
      toast({
        title: "Reward Redeemed!",
        description: `You've successfully redeemed: ${data.reward.title}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to redeem reward",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Handle claiming challenge rewards
  const claimChallengeMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      // In a real app, this would call an API endpoint
      const challenge = challenges.find(c => c.id === challengeId);
      if (!challenge) throw new Error("Challenge not found");
      
      // Here we're just simulating the API call
      return { success: true, challenge };
    },
    onSuccess: (data) => {
      // Mark the challenge as completed
      setChallenges(prev => 
        prev.map(c => 
          c.id === data.challenge.id 
            ? { ...c, completedDate: new Date().toISOString() } 
            : c
        )
      );
      
      // Increase the user's points
      if (user) {
        queryClient.setQueryData(['/api/user'], (oldData: any) => ({
          ...oldData,
          ecoPoints: oldData.ecoPoints + data.challenge.reward,
        }));
      }
      
      // Show success message
      toast({
        title: "Challenge Completed!",
        description: `You've earned ${data.challenge.reward} eco-points!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to claim reward",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Listen for WebSocket events to update challenge progress
  useEffect(() => {
    if (lastFootstepData) {
      // Update footsteps challenge
      setChallenges(prev => 
        prev.map(challenge => {
          if (challenge.type === 'footsteps') {
            const newCurrent = Math.min(challenge.current + lastFootstepData.footsteps, challenge.goal);
            const newProgress = Math.floor((newCurrent / challenge.goal) * 100);
            
            return {
              ...challenge,
              current: newCurrent,
              progress: newProgress
            };
          }
          return challenge;
        })
      );
      
      // Show a toast if a challenge is completed
      const footstepChallenge = challenges.find(c => c.type === 'footsteps');
      if (footstepChallenge && 
          footstepChallenge.current < footstepChallenge.goal && 
          footstepChallenge.current + lastFootstepData.footsteps >= footstepChallenge.goal) {
        toast({
          title: "Challenge Completed!",
          description: `You've completed the "${footstepChallenge.title}" challenge!`,
        });
      }
    }
  }, [lastFootstepData, toast]);
  
  // Listen for issue reports to update recycling challenge
  useEffect(() => {
    // We would listen for issue reports here and update the recycling challenge
    const listener = () => {
      queryClient.getQueryData(['/api/issues'])?.length;
    };
    
    return () => {
      // cleanup if needed
    };
  }, [queryClient]);
  
  function Footprints(props: any) {
    return <span {...props}><Zap /></span>;
  }
  
  function Recycle(props: any) {
    return <span {...props}><Leaf /></span>;
  }
  
  function Users(props: any) {
    return <span {...props}><Award /></span>;
  }
  
  function Bike(props: any) {
    return <span {...props}><ArrowRight /></span>;
  }

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row items-start justify-between mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <GamepadIcon className="w-8 h-8 text-primary" />
            Games & Rewards
          </h1>
          <p className="text-muted-foreground mt-2">
            Play games, complete challenges and earn rewards for your sustainable actions!
          </p>
        </div>
        
        <Card className="w-full md:w-auto">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Trophy className="w-6 h-6 text-amber-500" />
              <div>
                <p className="text-sm text-muted-foreground">Your Eco-Points</p>
                <p className="text-2xl font-bold">{userPoints}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs 
        defaultValue="rewards" 
        className="w-full mt-6"
        onValueChange={setCurrentTab}
      >
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="rewards">Rewards</TabsTrigger>
          <TabsTrigger value="games">Challenges & Games</TabsTrigger>
        </TabsList>
        
        <TabsContent value="rewards" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {rewards.map(reward => (
              <RewardCard 
                key={reward.id}
                title={reward.title}
                description={reward.description}
                points={reward.points}
                image={reward.image}
                currentPoints={userPoints}
                onRedeem={() => redeemRewardMutation.mutate(reward.id)}
                isRedeeming={redeemRewardMutation.isPending}
              />
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="games" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            {challenges.map(challenge => (
              <ChallengeCard 
                key={challenge.id}
                title={challenge.title}
                description={challenge.description}
                reward={challenge.reward}
                progress={challenge.progress}
                completed={challenge.progress >= 100}
                onClaim={() => claimChallengeMutation.mutate(challenge.id)}
                isClaiming={claimChallengeMutation.isPending}
                icon={challenge.imageIcon}
                current={challenge.current}
                goal={challenge.goal}
              />
            ))}
          </div>
          
          <Card className="mt-8 border-2 border-dashed border-primary/20">
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <GamepadIcon className="w-12 h-12 text-primary/50 mb-4" />
                <h3 className="text-xl font-semibold mb-2">Interactive Eco Games</h3>
                <div className="text-sm bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 p-3 rounded-md mb-4 border border-amber-200 dark:border-amber-800">
                  <div className="flex items-start">
                    <div className="mr-2 mt-0.5">⏳</div>
                    <p>Coming Soon! These fun interactive games will be available in a future update. Stay tuned!</p>
                  </div>
                </div>
                <p className="text-muted-foreground mb-4">
                  Play fun interactive games while learning about sustainability and earning eco-points!
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                  <Button className="w-full" variant="outline" disabled>
                    <Star className="mr-2 h-4 w-4" />
                    EcoQuiz
                  </Button>
                  <Button className="w-full" variant="outline" disabled>
                    <Star className="mr-2 h-4 w-4" />
                    Recycle Rush
                  </Button>
                  <Button className="w-full" variant="outline" disabled>
                    <Star className="mr-2 h-4 w-4" />
                    Energy Saver
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function RewardCard({ 
  title, 
  description, 
  points, 
  image, 
  currentPoints,
  onRedeem,
  isRedeeming
}: { 
  title: string; 
  description: string; 
  points: number; 
  image: string; 
  currentPoints: number;
  onRedeem: () => void;
  isRedeeming: boolean;
}) {
  const canRedeem = currentPoints >= points;
  
  return (
    <Card className="overflow-hidden">
      <div className="h-40 bg-primary/10 flex items-center justify-center">
        <Gift className="w-16 h-16 text-primary/60" />
      </div>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-lg">{title}</h3>
          <div className="flex items-center gap-1 bg-primary/10 text-primary px-2 py-1 rounded-full text-sm">
            <Trophy className="w-3.5 h-3.5" />
            {points}
          </div>
        </div>
        <p className="text-sm text-muted-foreground mb-4">{description}</p>
        
        {!canRedeem && (
          <div className="mb-3">
            <div className="flex justify-between text-xs mb-1">
              <span>{currentPoints} points</span>
              <span>{points} points</span>
            </div>
            <Progress value={(currentPoints / points) * 100} className="h-2" />
          </div>
        )}
        
        <Button 
          className="w-full mt-2" 
          variant={canRedeem ? "default" : "outline"}
          disabled={!canRedeem || isRedeeming}
          onClick={onRedeem}
        >
          {isRedeeming ? (
            <>
              <span className="animate-spin mr-2">⏳</span>
              Redeeming...
            </>
          ) : canRedeem ? (
            "Redeem Reward"
          ) : (
            `Earn ${points - currentPoints} more points`
          )}
        </Button>
      </CardContent>
    </Card>
  );
}

function ChallengeCard({ 
  title, 
  description, 
  reward, 
  progress,
  completed,
  onClaim,
  isClaiming,
  icon,
  current,
  goal
}: { 
  title: string; 
  description: string; 
  reward: number; 
  progress: number;
  completed: boolean;
  onClaim: () => void;
  isClaiming: boolean;
  icon: React.ReactNode;
  current: number;
  goal: number;
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between mb-2">
          <h3 className="font-semibold text-lg flex items-center gap-2">
            {icon || <Award className="w-5 h-5 text-primary" />}
            {title}
          </h3>
          <div className="flex items-center gap-1 bg-primary/10 text-primary px-2 py-1 rounded-full text-sm">
            <Trophy className="w-3.5 h-3.5" />
            {reward}
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground mb-2">{description}</p>
        
        <div className="flex justify-between items-center mb-1 text-xs text-muted-foreground">
          <span>Progress ({current}/{goal})</span>
          <span>{progress}%</span>
        </div>
        
        <div className="mb-4">
          <Progress value={progress} className="h-2" />
        </div>
        
        <Button 
          className="w-full gap-1" 
          variant={completed ? "default" : "outline"}
          disabled={!completed || isClaiming}
          onClick={onClaim}
        >
          {isClaiming ? (
            <>
              <span className="animate-spin mr-2">⏳</span>
              Processing...
            </>
          ) : completed ? (
            <>
              Claim Reward
              <CheckCircle className="w-4 h-4 ml-1" />
            </>
          ) : (
            <>
              Continue Challenge
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}