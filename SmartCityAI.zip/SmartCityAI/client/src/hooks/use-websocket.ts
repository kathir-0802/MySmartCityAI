import { useEffect, useRef, useCallback, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useAuth } from './use-auth';
import { useToast } from './use-toast';

type FootstepEnergyData = {
  stationId: number;
  footsteps: number;
  energyGenerated: number;
  pointsEarned: number;
  greenScoreEarned?: number;
};

type BioChargeUpdateData = {
  stationId: number;
  status: string;
  energyGenerated: number;
  footstepsCount: number;
};

type BioChargeStatusData = {
  stationId: number;
  status: string;
  energyLevel: number;
  lastUpdated: string;
};

type WSMessageType = 
  | 'auth' 
  | 'points_update' 
  | 'green_score_update' 
  | 'new_notification' 
  | 'issue_update' 
  | 'biocharge_update' 
  | 'footstep_energy_update' 
  | 'biocharge_status_update'
  | 'connection_established'
  | 'biocharge_interaction'
  | 'biocharge_status_request';

export function useWebSocket() {
  const wsRef = useRef<WebSocket | null>(null);
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isConnected, setIsConnected] = useState(false);
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const [lastFootstepData, setLastFootstepData] = useState<FootstepEnergyData | null>(null);
  const [lastStationStatus, setLastStationStatus] = useState<BioChargeStatusData | null>(null);

  const connect = useCallback(() => {
    if (!user) return;

    // If too many failed attempts, wait longer before retrying
    if (connectionAttempts > 5) {
      setTimeout(() => setConnectionAttempts(0), 10000);
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      setIsConnected(true);
      setConnectionAttempts(0);
      
      // Send authentication info to the server
      ws.send(JSON.stringify({
        type: 'auth',
        userId: user.id
      }));
      
      console.log('WebSocket connected');
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        console.log('WebSocket message received:', message.type);

        switch (message.type) {
          case 'connection_established':
            setIsConnected(true);
            break;
            
          case 'points_update':
            if (message.data.userId === user.id) {
              queryClient.setQueryData(['/api/user'], (oldData: any) => ({
                ...oldData,
                ecoPoints: message.data.points,
              }));
              toast({
                title: 'Points Updated',
                description: `You now have ${message.data.points} eco-points!`,
              });
            }
            break;

          case 'green_score_update':
            if (message.data.userId === user.id) {
              queryClient.setQueryData(['/api/user'], (oldData: any) => ({
                ...oldData,
                greenScore: message.data.score,
              }));
            }
            break;

          case 'new_notification':
            queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
            break;

          case 'issue_update':
            queryClient.invalidateQueries({ queryKey: ['/api/issues'] });
            break;
            
          case 'biocharge_update':
            const biochargeData = message.data as BioChargeUpdateData;
            queryClient.invalidateQueries({ queryKey: ['/api/biocharge/stations'] });
            queryClient.invalidateQueries({ queryKey: ['/api/biocharge/stats'] });
            
            toast({
              title: 'BioCharge Station Updated',
              description: `Station ${biochargeData.stationId} has generated ${biochargeData.energyGenerated.toFixed(1)} kWh of energy!`,
            });
            break;
            
          case 'footstep_energy_update':
            const footstepData = message.data as FootstepEnergyData;
            setLastFootstepData(footstepData);
            
            // Update points in cache
            queryClient.setQueryData(['/api/user'], (oldData: any) => {
              if (!oldData) return oldData;
              return {
                ...oldData,
                ecoPoints: oldData.ecoPoints + footstepData.pointsEarned,
                greenScore: oldData.greenScore + (footstepData.greenScoreEarned || 0),
              };
            });
            
            // Refresh station data
            queryClient.invalidateQueries({ queryKey: ['/api/biocharge/stations'] });
            queryClient.invalidateQueries({ queryKey: ['/api/biocharge/stats'] });
            
            toast({
              title: 'Energy Generated!',
              description: `Your ${footstepData.footsteps} footsteps generated ${footstepData.energyGenerated.toFixed(3)} kWh and earned you ${footstepData.pointsEarned} eco-points!`,
            });
            break;
            
          case 'biocharge_status_update':
            const statusData = message.data as BioChargeStatusData;
            setLastStationStatus(statusData);
            
            // Refresh station data to get the latest changes
            queryClient.invalidateQueries({ queryKey: ['/api/biocharge/stations'] });
            break;
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    ws.onerror = (event) => {
      console.error('WebSocket error:', event);
      setIsConnected(false);
      setConnectionAttempts(prev => prev + 1);
    };

    ws.onclose = () => {
      console.log('WebSocket closed, attempting to reconnect...');
      setIsConnected(false);
      setConnectionAttempts(prev => prev + 1);
      
      // Try to reconnect after a delay
      setTimeout(connect, 3000);
    };

    wsRef.current = ws;
  }, [user, queryClient, toast, connectionAttempts]);

  // Function to send a message to BioCharge station
  const sendFootstepData = useCallback((stationId: number, footsteps: number) => {
    console.log('Sending footstep data:', { stationId, footsteps });
    
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'biocharge_interaction',
        data: {
          stationId,
          footsteps
        }
      }));
      return true;
    } else {
      toast({
        title: 'Connection Error',
        description: 'Not connected to server. Attempting to reconnect...',
        variant: 'destructive'
      });
      
      // Try to reconnect
      connect();
      return false;
    }
  }, [toast, connect]);

  // Function to request real-time BioCharge station data from server
  const requestStationStatus = useCallback((stationId: number) => {
    console.log('Requesting station status:', stationId);
    
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'biocharge_status_request',
        data: { stationId }
      }));
      return true;
    } else {
      // Silently try to reconnect without showing an error
      connect();
      return false;
    }
  }, [connect]);

  // Function to refresh all BioCharge stats
  const refreshBioChargeStats = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ['/api/biocharge/stations'] });
    queryClient.invalidateQueries({ queryKey: ['/api/biocharge/stats'] });
  }, [queryClient]);

  // Connect when the component mounts or when user changes
  useEffect(() => {
    if (user) {
      connect();
    }
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect, user]);

  // Setup ping interval to keep connection alive
  useEffect(() => {
    const pingInterval = setInterval(() => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'ping' }));
      }
    }, 30000); // Send ping every 30 seconds
    
    return () => clearInterval(pingInterval);
  }, []);

  return {
    isConnected,
    lastFootstepData,
    lastStationStatus,
    sendFootstepData,
    requestStationStatus,
    refreshBioChargeStats
  };
}
