import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import ReportIssue from "@/pages/report-issue";
import Notifications from "@/pages/notifications";
import HowToUse from "@/pages/how-to-use";
import About from "@/pages/about";
import BioCharge from "@/pages/biocharge";
import AIAssistant from "@/pages/ai-assistant";
import GamesRewards from "@/pages/games-rewards";
import { SidebarNav } from "@/components/ui/sidebar-nav";
import { ProtectedRoute } from "@/lib/protected-route";
import { useState } from "react";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

function Layout({ children }: { children: React.ReactNode }) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen">
      <div className={`${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} fixed inset-y-0 z-50 md:translate-x-0 md:relative transition-transform duration-200 ease-in-out`}>
        <SidebarNav onClose={() => setIsSidebarOpen(false)} />
      </div>
      <div className="flex-1">
        <div className="sticky top-0 z-40 bg-background border-b p-4 md:hidden">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="hover:bg-accent"
          >
            <Menu className="h-6 w-6 text-foreground" />
          </Button>
        </div>
        <main className="flex-1">{children}</main>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute
        path="/"
        component={() => (
          <Layout>
            <Dashboard />
          </Layout>
        )}
      />
      <ProtectedRoute
        path="/report"
        component={() => (
          <Layout>
            <ReportIssue />
          </Layout>
        )}
      />
      <ProtectedRoute
        path="/notifications"
        component={() => (
          <Layout>
            <Notifications />
          </Layout>
        )}
      />
      <ProtectedRoute
        path="/how-to-use"
        component={() => (
          <Layout>
            <HowToUse />
          </Layout>
        )}
      />
      <ProtectedRoute
        path="/about"
        component={() => (
          <Layout>
            <About />
          </Layout>
        )}
      />
      <ProtectedRoute
        path="/biocharge"
        component={() => (
          <Layout>
            <BioCharge />
          </Layout>
        )}
      />
      <ProtectedRoute
        path="/ai-assistant"
        component={() => (
          <Layout>
            <AIAssistant />
          </Layout>
        )}
      />
      <ProtectedRoute
        path="/games-rewards"
        component={() => (
          <Layout>
            <GamesRewards />
          </Layout>
        )}
      />
      
      {/* Redirect from /help-us to /notifications */}
      <Route path="/help-us">
        <Redirect to="/notifications" />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;