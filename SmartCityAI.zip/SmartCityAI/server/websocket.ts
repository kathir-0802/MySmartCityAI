import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { User, CityIssue, Notification } from '@shared/schema';
import { storage } from './storage';

type WSMessage = {
  type: 'points_update' | 'green_score_update' | 'new_notification' | 'issue_update' | 'biocharge_update' | 'footstep_energy_update' | 'biocharge_status_update';
  data: any;
};

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: '/ws' });
  
  // Keep track of clients with their user IDs
  const clients = new Map<WebSocket, { userId?: number }>();

  wss.on('connection', (ws) => {
    console.log('Client connected');
    clients.set(ws, {});

    ws.on('message', async (message) => {
      try {
        const parsedMessage = JSON.parse(message.toString());
        const clientData = clients.get(ws) || {};
        
        // If the message contains authentication info, store the userId
        if (parsedMessage.type === 'auth' && parsedMessage.userId) {
          clients.set(ws, { userId: parsedMessage.userId });
        }
        
        // Handle BioCharge interaction - when user generates energy from footsteps
        if (parsedMessage.type === 'biocharge_interaction' && clientData.userId) {
          const { stationId, footsteps } = parsedMessage.data;
          
          // Calculate energy generated from footsteps (5 joules per step)
          const energyGenerated = (footsteps * 5) / 3600000; // Convert joules to kWh
          const pointsEarned = Math.floor(footsteps / 100); // 1 point per 100 steps
          
          // Create response data
          const responseData = {
            stationId,
            footsteps,
            energyGenerated,
            pointsEarned,
            greenScoreEarned: Math.floor(pointsEarned / 2) // Half of points earned
          };
          
          // Update user's points in the database
          if (clientData.userId) {
            const user = await storage.getUser(clientData.userId);
            if (user) {
              // Update points
              const updatedUser = await storage.updateUserPoints(
                user.id,
                user.ecoPoints + pointsEarned
              );
              
              // Update green score
              await storage.updateGreenScore(
                updatedUser.id,
                updatedUser.greenScore + Math.floor(pointsEarned / 2)
              );
              
              // Create notification
              await storage.createNotification({
                userId: clientData.userId,
                title: "Energy Generated",
                message: `You've generated ${energyGenerated.toFixed(3)} kWh of energy from ${footsteps} footsteps and earned ${pointsEarned} eco points!`,
                type: "biocharge"
              });
            }
          }
          
          // Send response to the client
          ws.send(JSON.stringify({
            type: 'footstep_energy_update',
            data: responseData
          }));
        }
        
        // Handle request for real-time BioCharge station status
        if (parsedMessage.type === 'biocharge_status_request') {
          const { stationId } = parsedMessage.data;
          
          // In a real app, you would fetch the latest station data from a database
          // Here we just send a mock update to simulate real-time changes
          ws.send(JSON.stringify({
            type: 'biocharge_status_update',
            data: {
              stationId,
              status: 'active',
              energyLevel: Math.floor(Math.random() * 100),
              lastUpdated: new Date().toISOString()
            }
          }));
        }
      } catch (err) {
        console.error('Error processing WebSocket message:', err);
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected');
      clients.delete(ws);
    });
    
    // Send initial connection confirmation
    ws.send(JSON.stringify({
      type: 'connection_established',
      data: { connected: true, timestamp: new Date().toISOString() }
    }));
  });

  return {
    broadcast: (message: WSMessage) => {
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(message));
        }
      });
    },
    
    // Function to send a message to a specific user
    sendToUser: (userId: number, message: WSMessage) => {
      clients.forEach((data, client) => {
        if (data.userId === userId && client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(message));
        }
      });
    },
    
    // Function to send a message to all users except one
    broadcastExcept: (excludeUserId: number, message: WSMessage) => {
      clients.forEach((data, client) => {
        if (data.userId !== excludeUserId && client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(message));
        }
      });
    }
  };
}
