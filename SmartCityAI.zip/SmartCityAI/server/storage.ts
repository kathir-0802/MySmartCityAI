import { InsertUser, User, CityIssue, Notification } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByResetToken(token: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User>;
  updateGreenScore(userId: number, score: number): Promise<User>;
  setResetToken(userId: number, token: string, expiry: Date): Promise<void>;
  clearResetToken(userId: number): Promise<void>;
  updatePassword(userId: number, hashedPassword: string): Promise<void>;

  // City issue operations
  createIssue(issue: Omit<CityIssue, "id" | "createdAt">): Promise<CityIssue>;
  getIssues(userId: number): Promise<CityIssue[]>;
  updateIssueStatus(issueId: number, status: string): Promise<CityIssue>;

  // Notification operations
  createNotification(notification: Omit<Notification, "id" | "createdAt" | "read">): Promise<Notification>;
  getNotifications(userId: number): Promise<Notification[]>;
  markNotificationRead(notificationId: number): Promise<Notification>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private issues: Map<number, CityIssue>;
  private notifications: Map<number, Notification>;
  sessionStore: session.Store;
  private currentId: { users: number; issues: number; notifications: number };

  constructor() {
    this.users = new Map();
    this.issues = new Map();
    this.notifications = new Map();
    this.currentId = { users: 1, issues: 1, notifications: 1 };
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async getUserByResetToken(token: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.resetToken === token,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = {
      ...insertUser,
      id,
      ecoPoints: 0,
      greenScore: 0,
      resetToken: null,
      resetTokenExpiry: null,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPoints(userId: number, points: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    const updated = { ...user, ecoPoints: user.ecoPoints + points };
    this.users.set(userId, updated);
    return updated;
  }

  async updateGreenScore(userId: number, score: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    const updated = { ...user, greenScore: score };
    this.users.set(userId, updated);
    return updated;
  }

  async setResetToken(userId: number, token: string, expiry: Date): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    const updated = { ...user, resetToken: token, resetTokenExpiry: expiry };
    this.users.set(userId, updated);
  }

  async clearResetToken(userId: number): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    const updated = { ...user, resetToken: null, resetTokenExpiry: null };
    this.users.set(userId, updated);
  }

  async updatePassword(userId: number, hashedPassword: string): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    const updated = { ...user, password: hashedPassword };
    this.users.set(userId, updated);
  }

  async createIssue(issue: Omit<CityIssue, "id" | "createdAt">): Promise<CityIssue> {
    const id = this.currentId.issues++;
    const newIssue: CityIssue = {
      ...issue,
      id,
      createdAt: new Date(),
    };
    this.issues.set(id, newIssue);
    return newIssue;
  }

  async getIssues(userId: number): Promise<CityIssue[]> {
    return Array.from(this.issues.values()).filter(
      (issue) => issue.userId === userId,
    );
  }

  async updateIssueStatus(issueId: number, status: string): Promise<CityIssue> {
    const issue = this.issues.get(issueId);
    if (!issue) throw new Error("Issue not found");
    const updated = { ...issue, status };
    this.issues.set(issueId, updated);
    return updated;
  }

  async createNotification(
    notification: Omit<Notification, "id" | "createdAt" | "read">,
  ): Promise<Notification> {
    const id = this.currentId.notifications++;
    const newNotification: Notification = {
      ...notification,
      id,
      read: false,
      createdAt: new Date(),
    };
    this.notifications.set(id, newNotification);
    return newNotification;
  }

  async getNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(
      (notification) => notification.userId === userId,
    );
  }

  async markNotificationRead(notificationId: number): Promise<Notification> {
    const notification = this.notifications.get(notificationId);
    if (!notification) throw new Error("Notification not found");
    const updated = { ...notification, read: true };
    this.notifications.set(notificationId, updated);
    return updated;
  }
}

export const storage = new MemStorage();