import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertIssueSchema, forgotPasswordSchema, resetPasswordSchema } from "@shared/schema";
import { setupWebSocket } from "./websocket";
import { nanoid } from "nanoid";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);
  const httpServer = createServer(app);
  const ws = setupWebSocket(httpServer);

  // City Issues
  app.post("/api/issues", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      // Check if the image size is too large (>20MB after base64 encoding)
      if (req.body.imageUrl && req.body.imageUrl.length > 20 * 1024 * 1024) {
        return res.status(413).json({ message: "Image size too large. Please use a smaller image or compress it." });
      }

      const validation = insertIssueSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json(validation.error);
      }

      const issue = await storage.createIssue({
        ...validation.data,
        userId: req.user!.id,
        status: "pending",
      });

      // Award eco points for reporting an issue
      const pointsForReport = 20;
      const greenScoreIncrease = 5;
      
      // Update user's eco points
      const userWithPoints = await storage.updateUserPoints(req.user!.id, req.user!.ecoPoints + pointsForReport);
      
      // Update user's green score
      const userWithGreenScore = await storage.updateGreenScore(userWithPoints.id, userWithPoints.greenScore + greenScoreIncrease);

      // Broadcast the new issue to all connected clients
      ws.broadcast({
        type: 'issue_update',
        data: issue,
      });
      
      // Broadcast points update
      ws.broadcast({
        type: 'points_update',
        data: { userId: userWithGreenScore.id, points: userWithGreenScore.ecoPoints },
      });
      
      // Broadcast green score update
      ws.broadcast({
        type: 'green_score_update',
        data: { userId: userWithGreenScore.id, score: userWithGreenScore.greenScore },
      });

      // Create a notification for the user
      const notification = await storage.createNotification({
        userId: req.user!.id,
        title: "Issue Reported",
        message: `You've earned ${pointsForReport} eco points and ${greenScoreIncrease} green score for reporting an issue!`,
        type: "points" 
      });
      
      // Broadcast notification
      ws.broadcast({
        type: 'new_notification',
        data: notification,
      });

      res.status(201).json({
        ...issue,
        pointsEarned: pointsForReport,
        greenScoreEarned: greenScoreIncrease
      });
    } catch (error: any) {
      console.error("Error in /api/issues:", error.message);
      res.status(500).json({ message: "Error processing your request. Please try again with a smaller image." });
    }
  });

  app.get("/api/issues", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const issues = await storage.getIssues(req.user!.id);
    res.json(issues);
  });

  // Password management
  app.post("/api/forgot-password", async (req, res) => {
    try {
      // Validate input with schema
      const validation = forgotPasswordSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json(validation.error);
      }

      const { email } = validation.data;
      const user = await storage.getUserByEmail(email);
      
      // Don't reveal whether a user exists for security reasons
      if (user) {
        // Generate a token using nanoid for better security
        const token = nanoid(32); // longer token for better security
        
        // Set token expiry to 24 hours from now
        const expiry = new Date();
        expiry.setHours(expiry.getHours() + 24);
        
        // Save token to user record
        await storage.setResetToken(user.id, token, expiry);
        
        // In a real app, you would send an email with a reset link
        console.log(`Password reset token for ${email}: ${token}`);
        console.log(`Reset link would be: ${process.env.APP_URL || 'http://localhost:5000'}/auth?token=${token}`);
        
        // In a production environment, you would use an email service like SendGrid, Mailgun, etc.
        // Example:
        // await sendEmail({
        //   to: email,
        //   subject: "Reset Your Password",
        //   text: `Click this link to reset your password: ${process.env.APP_URL}/auth?token=${token}`,
        //   html: `<p>Click <a href="${process.env.APP_URL}/auth?token=${token}">here</a> to reset your password.</p>`
        // });
        
        // For development, return the token (NOT for production)
        if (process.env.NODE_ENV !== 'production') {
          return res.status(200).json({ 
            message: "Reset link sent. Check your email.",
            resetToken: token // Only in development
          });
        }
      }
      
      // Always respond with success, even if no user was found (for security)
      return res.status(200).json({ 
        message: "If an account with that email exists, a password reset link will be sent." 
      });
    } catch (error) {
      console.error("Error in forgot password:", error);
      return res.status(500).json({ message: "An error occurred processing your request" });
    }
  });
  
  app.post("/api/reset-password", async (req, res) => {
    try {
      // Validate input with schema
      const validation = resetPasswordSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json(validation.error);
      }
      
      const { token, password } = validation.data;
      
      // Find user with this token
      const user = await storage.getUserByResetToken(token);
      
      if (!user || !user.resetTokenExpiry) {
        return res.status(400).json({ message: "Invalid or expired token" });
      }
      
      // Check if token is expired
      if (new Date() > new Date(user.resetTokenExpiry)) {
        return res.status(400).json({ message: "Token has expired. Please request a new password reset link." });
      }
      
      // Hash the new password using the same function used during registration
      const hashedPassword = await hashPassword(password);
      
      // Update password and clear token
      await storage.updatePassword(user.id, hashedPassword);
      await storage.clearResetToken(user.id);
      
      // Create a notification for the user
      await storage.createNotification({
        userId: user.id,
        title: "Password Updated",
        message: "Your password has been reset successfully.",
        type: "security"
      });
      
      return res.status(200).json({ message: "Password has been reset successfully" });
    } catch (error) {
      console.error("Error in reset password:", error);
      return res.status(500).json({ message: "An error occurred processing your request" });
    }
  });

  // Notifications
  app.get("/api/notifications", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const notifications = await storage.getNotifications(req.user!.id);
    res.json(notifications);
  });

  app.post("/api/notifications/:id/read", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const notification = await storage.markNotificationRead(parseInt(req.params.id));

    // Broadcast notification update
    ws.broadcast({
      type: 'new_notification',
      data: notification,
    });

    res.json(notification);
  });

  // Points and Scores
  app.post("/api/points", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = await storage.updateUserPoints(req.user!.id, req.body.points);

    // Broadcast points update
    ws.broadcast({
      type: 'points_update',
      data: { userId: user.id, points: user.ecoPoints },
    });

    res.json(user);
  });

  app.post("/api/green-score", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = await storage.updateGreenScore(req.user!.id, req.body.score);

    // Broadcast score update
    ws.broadcast({
      type: 'green_score_update',
      data: { userId: user.id, score: user.greenScore },
    });

    res.json(user);
  });

  // BioCharge stations
  app.get("/api/biocharge/stations", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // BioCharge stations data with location information for Malaysia
    const stations = [
      {
        id: 1,
        name: "KLCC BioCharge Station",
        location: { lat: 3.1587, lng: 101.7120 },
        status: "active",
        energyGenerated: 245.6, // kWh
        footstepsCount: 18750,
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 2,
        name: "Bukit Bintang Walkway BioCharge",
        location: { lat: 3.1472, lng: 101.7073 },
        status: "active",
        energyGenerated: 189.2, // kWh
        footstepsCount: 14320,
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 3,
        name: "Universiti Malaya BioCharge",
        location: { lat: 3.1209, lng: 101.6538 },
        status: "maintenance",
        energyGenerated: 123.5, // kWh
        footstepsCount: 9870,
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 4,
        name: "KL Sentral Transit Hub BioCharge",
        location: { lat: 3.1344, lng: 101.6867 },
        status: "active",
        energyGenerated: 278.3, // kWh
        footstepsCount: 21540,
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 5,
        name: "Perdana Botanical Gardens BioCharge",
        location: { lat: 3.1427, lng: 101.6841 },
        status: "active",
        energyGenerated: 156.8, // kWh
        footstepsCount: 12450,
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 6,
        name: "Putrajaya Boulevard BioCharge",
        location: { lat: 2.9356, lng: 101.6906 },
        status: "active",
        energyGenerated: 178.5, // kWh
        footstepsCount: 13250,
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 7,
        name: "Cyberjaya Smart City Hub BioCharge",
        location: { lat: 2.9237, lng: 101.6559 },
        status: "active",
        energyGenerated: 201.7, // kWh
        footstepsCount: 15780,
        lastUpdated: new Date().toISOString(),
      }
    ];
    
    res.json(stations);
  });

  // BioCharge statistics 
  app.get("/api/biocharge/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // BioCharge statistics with Malaysian context
    const stats = {
      totalEnergyGenerated: 1373.6, // kWh
      totalFootsteps: 105960,
      co2Saved: 686.8, // kg
      deviceCharged: 11520,
      bikeCharged: 578,
      topStation: {
        id: 4,
        name: "KL Sentral Transit Hub BioCharge",
        energyGenerated: 278.3
      },
      userContribution: {
        footsteps: 1245,
        energyGenerated: 16.8,
        pointsEarned: 124
      },
      // Additional Malaysian-specific stats
      moneySaved: 458.7, // RM
      malaysianCities: [
        { city: "Kuala Lumpur", stations: 5, energy: 893.4 },
        { city: "Putrajaya", stations: 1, energy: 178.5 },
        { city: "Cyberjaya", stations: 1, energy: 201.7 },
        { city: "Penang", stations: 0, energy: 0, planned: true },
        { city: "Johor Bahru", stations: 0, energy: 0, planned: true }
      ],
      kWhPerYear: 12354.6,
      estimatedGrowth: 28.7 // %
    };
    
    res.json(stats);
  });
  
  // Generate energy from footsteps
  app.post("/api/biocharge/generate", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const { stationId, footsteps } = req.body;
    
    if (!stationId || !footsteps || footsteps <= 0) {
      return res.status(400).json({ error: "Invalid parameters" });
    }
    
    // Calculate energy based on footsteps (approx 5 joules per step)
    const energyGenerated = (footsteps * 5) / 3600000; // Convert joules to kWh
    const pointsEarned = Math.floor(footsteps / 100); // 1 point per 100 steps
    
    // Increase user's eco points
    const userWithPoints = await storage.updateUserPoints(
      req.user!.id, 
      req.user!.ecoPoints + pointsEarned
    );
    
    // Increase user's green score
    const greenScoreIncrease = Math.floor(pointsEarned / 2); // Half of points earned
    const userWithGreenScore = await storage.updateGreenScore(
      userWithPoints.id, 
      userWithPoints.greenScore + greenScoreIncrease
    );
    
    // Create a notification
    const notification = await storage.createNotification({
      userId: req.user!.id,
      title: "Energy Generated",
      message: `You've generated ${energyGenerated.toFixed(3)} kWh of energy from ${footsteps} footsteps and earned ${pointsEarned} eco points!`,
      type: "biocharge"
    });
    
    // Create response data
    const data = {
      stationId,
      footsteps,
      energyGenerated,
      pointsEarned,
      greenScoreEarned: greenScoreIncrease
    };
    
    // Send WebSocket broadcasts
    ws.broadcast({
      type: 'footstep_energy_update',
      data
    });
    
    ws.broadcast({
      type: 'points_update',
      data: { userId: userWithGreenScore.id, points: userWithGreenScore.ecoPoints }
    });
    
    ws.broadcast({
      type: 'green_score_update',
      data: { userId: userWithGreenScore.id, score: userWithGreenScore.greenScore }
    });
    
    ws.broadcast({
      type: 'new_notification',
      data: notification
    });
    
    res.status(200).json(data);
  });

  return httpServer;
}